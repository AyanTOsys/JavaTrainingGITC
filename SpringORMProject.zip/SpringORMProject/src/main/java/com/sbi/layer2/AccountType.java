package com.sbi.layer2;

public interface AccountType {
	String SAVINGS="SAVINGS";
	String CURRENT="CURRENT";
	String FIXEDDEPOSIT="FIXED DEPOSIT";
	String RECURRINGDEPOSIT="RECURRING DEPOSIT";
}
