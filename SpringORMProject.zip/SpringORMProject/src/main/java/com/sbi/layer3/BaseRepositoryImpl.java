package com.sbi.layer3;

import java.io.Serializable;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

@Repository
public class BaseRepositoryImpl implements BaseRepository{
	
	@PersistenceContext(unitName="MyJPA")
	EntityManager em;
	
	public BaseRepositoryImpl(){

	}
	
	@Transactional
	public void persist(Object obj) {
	
		em.persist(obj);
	}
	
	@Transactional
	public void merge(Object obj) {
		em.merge(obj);
	}
	
	@Transactional
	public void remove(Object obj) {
		em.remove(obj);
	}
	
	@Transactional
	public <E>E find(Class<E> className, Serializable primaryKey) {

		E e=em.find(className, primaryKey);
		return e;
	}
	
	@Transactional
	public <E> List<E> findAll(String entityName) {
		
		Query query=em.createQuery("from "+entityName);
		return query.getResultList();
	}
	
}
