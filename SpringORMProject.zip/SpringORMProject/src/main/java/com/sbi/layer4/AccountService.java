package com.sbi.layer4;

import org.springframework.stereotype.Service;

import com.sbi.layer2.Account;

@Service
public interface AccountService {
	void openBankAccountService(int applicantId);
}
