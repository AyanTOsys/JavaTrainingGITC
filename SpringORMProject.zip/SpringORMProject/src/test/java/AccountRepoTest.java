import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.sbi.layer2.Account;
import com.sbi.layer3.AccountRepository;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(locations="classpath:myspring.xml")
public class AccountRepoTest {
	
	@Autowired
	AccountRepository accRepo;
	
	@Test
	public void createAccountTest() {
		Account acObj=new Account();
		acObj.setAccountHolder("Ayan");
		acObj.setAccountBalance(1000);
		accRepo.createAccount(acObj);
	}
}
