import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.sbi.layer2.Account;
import com.sbi.layer2.AccountType;
import com.sbi.layer2.Address;
import com.sbi.layer2.Applicant;
import com.sbi.layer2.ApplicationStatus;
import com.sbi.layer3.AccountRepository;
import com.sbi.layer3.ApplicantRepository;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(locations="classpath:myspring.xml")
public class ApplicantRepoTesting {
	
	@Autowired
	ApplicantRepository applRepo;
	
	@Test
	public void applyForAccountTest() {
		Applicant applObj=new Applicant();
		
		applObj.setAccountType(AccountType.CURRENT);
		applObj.setApplicantName("Ghosh");
		applObj.setDateofBirth(LocalDate.of(1982,9,24));
		applObj.setApplicantFatherName("Zidane");
		applObj.setAdhaarNumber(48974644646d);
		applObj.setOccupation("Business");
		applObj.setMarried("Single");
		applObj.setMobileNumber(979797977);
		applObj.setPanNumber("APDAF7996F");
		applObj.setPhoto("photo.jpg");
		
		Address perObj=new Address();
		perObj.setAddressType("Home");
		perObj.setArea("Kolkata");
		perObj.setCity("Kolkata");
		perObj.setStreet("2nd By Lane");
		perObj.setState("WB");
		perObj.setCountry("India");
		perObj.setPin(711102);
		perObj.setAppl(applObj);
		
		Address corObj=new Address();
		corObj.setAddressType("Temporary");
		corObj.setArea("Vashi");
		corObj.setCity("N Mumbai");
		corObj.setStreet("Vashi");
		corObj.setState("Maharashtra");
		corObj.setCountry("India");
		corObj.setPin(400736);
		corObj.setAppl(applObj);
		
		
		List<Address> addList=new ArrayList<Address>();
		addList.add(perObj);
		addList.add(corObj);
		
		applObj.setAddressList(addList);
		applObj.setAnnualIncome(100000f);
		applObj.setApplicationStatus(ApplicationStatus.APPLIED);
		
		applRepo.createApplication(applObj);
	}
}
