import java.time.LocalDate;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.junit.jupiter.api.Test;

import entity.Employee;
import entity.PanCard;
import entity.Passport;

public class CrudTestingOneToOne {
	EntityManagerFactory emf;
	EntityManager em;
	
	public CrudTestingOneToOne() {
		System.out.println("Reading from persistence.xml..");
		this.emf = Persistence.createEntityManagerFactory("MyJPA");
		System.out.println("EntityManagerFactory created....");
		
		this.em = emf.createEntityManager();
		System.out.println("EntityManager created....");
	}
	
	@Test
	public void createNewEmpWithNewPassportTest() {
		Employee theEmp=new Employee();
		theEmp.setName("Jimmy");
		theEmp.setJob("Analyst");
		theEmp.setJoiningDate(LocalDate.of(2015, 5, 1));
		theEmp.setSalary(40000);
		theEmp.setAge(32);
		
		Passport passport=new Passport();
		passport.setIssuedBy("Govt of India");
		passport.setPassportIssuedDate(LocalDate.of(2020, 4, 1));
		passport.setPassportExpiryDate(LocalDate.of(2030, 3, 31));
		
		theEmp.setPassport(passport);
		passport.setEmp(theEmp);
		
		EntityTransaction tx=em.getTransaction();
		tx.begin();
			em.persist(theEmp);
			em.persist(passport);
		tx.commit();
	}
	
	@Test
	public void addNewEmployeeWithoutPassport() {
		Employee theEmp = new Employee();
		theEmp.setName("Sunny");
		theEmp.setJob("Manager");
		theEmp.setJoiningDate(LocalDate.of(2015, 6, 22));
		theEmp.setSalary(102000);
		theEmp.setAge(31); 
		EntityTransaction tx = em.getTransaction();
		tx.begin();
			em.persist(theEmp);
		tx.commit();
	}
	
	@Test
	public void addNewPassportWithoutAnEmployee() {
		Passport passport = new Passport();
		passport.setIssuedBy("Govt. Of. Uganda");
		passport.setPassportIssuedDate(LocalDate.of(2026, 12, 25));
		passport.setPassportExpiryDate(LocalDate.of(2036, 12, 25));
		EntityTransaction tx = em.getTransaction();
		tx.begin();
			em.persist(passport);
		tx.commit();
	}
	
	@Test
	public void assignExistingPassportToExistingEmployee() {
		
		EntityTransaction tx = em.getTransaction();
		tx.begin();
			Passport passport = em.find(Passport.class, 10);
			Employee theEmp   = em.find(Employee.class, 9);
		
			passport.setEmp(theEmp);
			theEmp.setPassport(passport);
			
			em.merge(passport);
			em.merge(theEmp);
		tx.commit();	
	}
	
	@Test
	public void assignExistingPassportToNewEmployee() {
		EntityTransaction tx1 = em.getTransaction();
		tx1.begin();
		
			Passport passport = em.find(Passport.class, 11); //ATTACHED
			
			Employee theEmp = new Employee(); //TRANSIENT
			theEmp.setName("JONES");
			theEmp.setJob("CLERK");
			theEmp.setJoiningDate(LocalDate.of(2015, 6, 22));
			theEmp.setSalary(72000);
			theEmp.setAge(33);
			theEmp.setPassport(passport);
			
			passport.setEmp(theEmp);

			em.persist(theEmp);
			em.merge(passport);
					
		tx1.commit();
	}
	
	@Test
	public void assignNewPassportToExistingEmployee() {
		
		EntityTransaction tx = em.getTransaction();
		tx.begin();
			
			Employee theEmp   = em.find(Employee.class, 13);

			Passport passport = new Passport();
			passport.setIssuedBy("Govt. Of. Ukrain");
			passport.setPassportIssuedDate(LocalDate.of(2026, 12, 25));
			passport.setPassportExpiryDate(LocalDate.of(2036, 12, 25));
			
			passport.setEmp(theEmp);
			theEmp.setPassport(passport);
			
			em.persist(passport);
			em.merge(theEmp);
		tx.commit();
	}
	
	@Test
	public void createNewEmpWithNewPancard() {
		Employee theEmp=new Employee();
		theEmp.setName("Jakson");
		theEmp.setJob("Analyst");
		theEmp.setJoiningDate(LocalDate.of(2019, 5, 1));
		theEmp.setSalary(45000);
		theEmp.setAge(32);
		
		PanCard pan=new PanCard();
		pan.setPancardNo("ADABD8965F");
		pan.setPanholderName("Jakson");
		pan.setPanholderFatherName("Robert");
		pan.setDateofBirth(LocalDate.of(1989, 6, 8));
		
		theEmp.setPancard(pan);
		pan.setEmp(theEmp);
		
		EntityTransaction tx=em.getTransaction();
		tx.begin();
			em.persist(theEmp);
			em.persist(pan);
		tx.commit();
	}
}
