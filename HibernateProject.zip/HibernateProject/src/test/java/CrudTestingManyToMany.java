import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.junit.jupiter.api.Test;

import entity.Customer;
import entity.Department;
import entity.Employee;
import entity.Passport;
import entity.Project;
import entity.Subscription;

public class CrudTestingManyToMany {
	EntityManagerFactory emf;
	EntityManager em;
	public CrudTestingManyToMany() {
		System.out.println("CrudTesingOnetoMany()...");
		System.out.println("Trying to read persistence.xml file...");
		
		this.emf = Persistence.createEntityManagerFactory("MyJPA");
		
		System.out.println("EntityManagerFactory created....");
		
		this.em = emf.createEntityManager();
		System.out.println("EntityManager created....");
	}
	
	@Test
	public void createSingleDepartmentTest() {
		
		Department dept = new Department("Sample","Sample");
		EntityTransaction tx = em.getTransaction();
		tx.begin();
			em.persist(dept);
		tx.commit();
	}
	
	@Test
	public void createNewDepartmentWithNewEmployeesTest() {
		
		Department dept = new Department("Operations","New Mumbai");
		
		Passport passport1 = new Passport();
		passport1.setIssuedBy("Govt. Of. India");
		passport1.setPassportIssuedDate(LocalDate.of(2011, 12, 25));
		passport1.setPassportExpiryDate(LocalDate.of(2021, 12, 25));
		
		Passport passport2 = new Passport();
		passport2.setIssuedBy("Govt. Of. Nepal");
		passport2.setPassportIssuedDate(LocalDate.of(2012, 12, 25));
		passport2.setPassportExpiryDate(LocalDate.of(2022, 12, 25));
		
		Passport passport3 = new Passport();
		passport3.setIssuedBy("Govt. Of. Srilanka");
		passport3.setPassportIssuedDate(LocalDate.of(2013, 12, 25));
		passport3.setPassportExpiryDate(LocalDate.of(2023, 12, 25));
		
		
		Employee emp1 = new Employee("Seeta","DBA",LocalDate.now(),62000,23,passport1,dept);
		Employee emp2 = new Employee("Reeta","DBA",LocalDate.now(),42000,23,passport2,dept);
		Employee emp3 = new Employee("Geeta","DBA",LocalDate.now(),32000,23,passport3,dept);
		
		passport1.setEmp(emp1);
		passport2.setEmp(emp2);
		passport3.setEmp(emp3);
		
		Set <Employee> tempStaff = new HashSet<Employee>();
		tempStaff.add(emp1); //triggering the insert query
		tempStaff.add(emp2);
		tempStaff.add(emp3);
		
		dept.setStaff(tempStaff);
		
		//OR
		
		//dept.getStaff().add(emp1);
		//dept.getStaff().add(emp2);
		//dept.getStaff().add(emp3);
		
		EntityTransaction tx = em.getTransaction();
		
		tx.begin();
			em.persist(dept);
				
		tx.commit();
		
	}
	
	@Test
	public void createCustomerTest(){
		Customer cust1=new Customer();
		Customer cust2=new Customer();
		Customer cust3=new Customer();
		
		cust1.setCustomerId(1);
		cust1.setCustomerName("Jones");
		cust1.setEmailAddress("jones@gmail.com");
		
		cust2.setCustomerId(2);
		cust2.setCustomerName("Johny");
		cust2.setEmailAddress("johny@gmail.com");
		
		cust3.setCustomerId(3);
		cust3.setCustomerName("Jimmy");
		cust3.setEmailAddress("jimmy@gmail.com");
		
		EntityTransaction tx = em.getTransaction();
		
		tx.begin();
			em.persist(cust1);
			em.persist(cust2);
			em.persist(cust3);
		tx.commit();
	}
	
	@Test
	public void createSubscriptionTest(){
		Subscription sub1=new Subscription();
		Subscription sub2=new Subscription();
		Subscription sub3=new Subscription();
		
		sub1.setSubscriptionId(101);
		sub1.setSubscriptionName("Amazon");
		sub1.setSubscriptionType("3M");
		
		sub2.setSubscriptionId(102);
		sub2.setSubscriptionName("Netflix");
		sub2.setSubscriptionType("6M");
		
		sub3.setSubscriptionId(103);
		sub3.setSubscriptionName("Zee5");
		sub3.setSubscriptionType("12M");
		
		EntityTransaction tx = em.getTransaction();
		
		tx.begin();
			em.persist(sub1);
			em.persist(sub2);
			em.persist(sub3);
		tx.commit();
	}
	
	@Test
	public void assignSubscriptionToCustomerTest() {
		Customer cust=em.find(Customer.class, 1);
		
		Subscription sub1=em.find(Subscription.class, 101);
		Subscription sub2=em.find(Subscription.class, 102);
		
		cust.getSub().add(sub1);
		cust.getSub().add(sub2);
		
		EntityTransaction tx = em.getTransaction();
		tx.begin();
			em.merge(cust);
		
		tx.commit();
	}
	
	@Test
	public void showSubscriptionNameByCustomerId(){
		Customer cust=em.find(Customer.class, 1);
		
		System.out.println("Customer name:"+cust.getCustomerName());
		
		Set<Subscription> subList=cust.getSub();
		for (Subscription subscription : subList) {
			System.out.println("Subscription name:"+subscription.getSubscriptionName());
			System.out.println("Subscription type:"+subscription.getSubscriptionType());
		}
	}
	
	@Test
	public void createProjectTest(){
		Project pro1=new Project();
		Project pro2=new Project();
		Project pro3=new Project();
		
		pro1.setProjectName("Java");
		pro1.setDeadline(LocalDate.of(2022, 6, 25));
		
		pro2.setProjectName("Javascript");
		pro2.setDeadline(LocalDate.of(2022, 9, 25));
		
		
		EntityTransaction tx = em.getTransaction();
		
		tx.begin();
			em.persist(pro1);
			em.persist(pro2);
			
		tx.commit();
	}
	
	@Test
	public void assignProjectToEmployeeTest() {
		Employee emp=em.find(Employee.class, 10);
		
		Project pro1=em.find(Project.class, 101);//pk value to be changed
		Project pro2=em.find(Project.class, 101);//pk value to be changed
		
		emp.getProjList().add(pro1);
		emp.getProjList().add(pro2);
		
		EntityTransaction tx = em.getTransaction();
		tx.begin();
			em.merge(emp);
		
		tx.commit();
	}
}
