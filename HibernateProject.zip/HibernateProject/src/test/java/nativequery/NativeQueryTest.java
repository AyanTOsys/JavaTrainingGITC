package nativequery;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import org.junit.jupiter.api.Test;

import dao.BaseDAO;
import dao.BaseDAOImpl;

public class NativeQueryTest {
	
	
	@Test
	public void showAllrecord() {
		BaseDAO baseDao=new BaseDAOImpl();
		List<Employees> staff=baseDao.findAll("EMP1");
		
		for (Employees employee : staff) {
			System.out.println("Employee number:"+employee.getEmployeeNumber());
			System.out.println("Employee name  :"+employee.getEmployeeName());
			System.out.println("Job            :"+employee.getJob());
			System.out.println("Manager ID     :"+employee.getMgr());
			System.out.println("Hire Date      :"+employee.getHiredate());
			System.out.println("Employee salary:"+employee.getSalary());
			System.out.println("Employee comm  :"+employee.getCommission());
			System.out.println("Department No  :"+employee.getDepartmentNumber());
			System.out.println("-------------------------------------------------");
		}
	}
	
	@Test
	public void showEmployeesAsPerSalary() {
		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("MyJPA"); 
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		
		Query query = 
			entityManager.createNativeQuery("SELECT * FROM EMP1 WHERE SAL >= 3000", Employees.class);
		
		List<Employees> staff = query.getResultList();
		
		for (Employees employee : staff) {
			System.out.println("Emp Number   : "+employee.getEmployeeNumber());
			System.out.println("Emp Name     : "+employee.getEmployeeName());
			System.out.println("Emp Manager  : "+employee.getMgr());
			System.out.println("Emp Job      : "+employee.getJob());
			System.out.println("Emp Hiredate : "+employee.getHiredate());
			System.out.println("Emp Salary   : "+employee.getSalary());
			System.out.println("Emp Comm     : "+employee.getCommission());
			System.out.println("Emp Deptno   : "+employee.getDepartmentNumber());
			System.out.println("------------------------");
		}
	}
}
