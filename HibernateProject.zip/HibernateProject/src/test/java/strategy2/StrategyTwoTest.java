package strategy2;
//import strategy2.BankAccount;
//import strategy2.CreditCard;

import org.junit.jupiter.api.Test;

import dao.BaseDAO;
import dao.BaseDAOImpl;

public class StrategyTwoTest {
	BaseDAO baseDao=new BaseDAOImpl();
	
	@Test
	public void testAddBankAccountTest() {
		BankAccount baObj=new BankAccount();
		
		baObj.setOwner("Ram");
		baObj.setBankName("CBI");		
		baObj.setIfsCode("CBIN001298");
		baObj.setAccountNumber("4564564564");
		
		
		baseDao.persist(baObj);
	}
	
	@Test
	public void testAddCreditCardTest() {
		strategy2.CreditCard ccObj=new CreditCard();
		
		ccObj.setCardType("VISA");
		ccObj.setExpiryMonth("Jun");
		ccObj.setExpiryYear("2026");
		ccObj.setOwner("Shyam");
		
		baseDao.persist(ccObj);
		
	}
}
