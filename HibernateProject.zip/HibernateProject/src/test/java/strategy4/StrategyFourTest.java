package strategy4;
//import strategy2.BankAccount;
//import strategy2.CreditCard;

import org.junit.jupiter.api.Test;

import dao.BaseDAO;
import dao.BaseDAOImpl;

public class StrategyFourTest {
	BaseDAO baseDao=new BaseDAOImpl();
	
	@Test
	public void testAddBankCreditDetailsTest() {
		
		
		BankAccount baObj=new BankAccount();
		
		baObj.setBankName("SBI");		
		baObj.setIfsCode("SBIN0001298");
		baObj.setAccountNumber("636323221");
		baObj.setOwner("Laxmi");
		
		
		CreditCard ccObj=new CreditCard();
		
		ccObj.setCardType("VISA");
		ccObj.setExpiryMonth("Jun");
		ccObj.setExpiryYear("2026");
		ccObj.setAccountNumber("636323221");
		ccObj.setOwner("Laxmi");
		
		
		baseDao.persist(ccObj);			
		baseDao.persist(baObj);
		
	}

}
