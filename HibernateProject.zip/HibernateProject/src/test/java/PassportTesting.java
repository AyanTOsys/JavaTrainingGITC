import javax.persistence.EntityTransaction;

import org.junit.jupiter.api.Test;

import dao.PassportDaoImpl;
import entity.Passport;

public class PassportTesting {
	PassportDaoImpl passportDao=new PassportDaoImpl();
	
	@Test
	public void addPassport() {
		
		
		
	}
}
