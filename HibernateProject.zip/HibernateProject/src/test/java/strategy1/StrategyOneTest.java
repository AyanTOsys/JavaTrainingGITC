package strategy1;

import org.junit.jupiter.api.Test;

import dao.BaseDAO;
import dao.BaseDAOImpl;

public class StrategyOneTest {
	BaseDAO baseDao=new BaseDAOImpl();
	
	@Test
	public void testAddBankAccountTest() {
		BankAccount baObj=new BankAccount();
		baObj.setBankName("SBI");
		baObj.setOwner("Ram");
		baObj.setIfsCode("SBI0001298");
		
		baseDao.persist(baObj);
	}
	
	@Test
	public void testAddCreditCardTest() {
		CreditCard ccObj=new CreditCard();
		
		ccObj.setCardType("VISA");
		ccObj.setExpiryMonth("Jun");
		ccObj.setExpiryYear("2026");
		ccObj.setOwner("Shyam");
		
		baseDao.persist(ccObj);
		
	}
}
