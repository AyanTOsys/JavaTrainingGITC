package strategy3;
//import strategy2.BankAccount;
//import strategy2.CreditCard;

import org.junit.jupiter.api.Test;

import dao.BaseDAO;
import dao.BaseDAOImpl;

public class StrategyThreeTest {
	BaseDAO baseDao=new BaseDAOImpl();
	
	@Test
	public void testAddAllDetailsTest() {
		
		BillingDetails billObj=new BillingDetails();
		billObj.setAccountNumber("636364321");
		billObj.setOwner("Razor");
		
		
		BankAccount baObj=new BankAccount();
		
		baObj.setBankName("SBI");		
		baObj.setIfsCode("SBIN0001298");
		baObj.setAccountNumber("636364321");
		baObj.setOwner("Razor");
		
		
		CreditCard ccObj=new CreditCard();
		
		ccObj.setCardType("MASTER");
		ccObj.setExpiryMonth("Jun");
		ccObj.setExpiryYear("2026");
		baObj.setAccountNumber("636364321");
		baObj.setOwner("Razor");
		
		baseDao.persist(billObj);
		baseDao.persist(ccObj);			
		baseDao.persist(baObj);
		
	}

}
