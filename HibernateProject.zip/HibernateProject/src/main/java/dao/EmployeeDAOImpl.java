package dao;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import entity.Employee;

public class EmployeeDAOImpl implements EmployeeDAO {
	
	EntityManagerFactory emf;
	EntityManager em;
	
	public EmployeeDAOImpl() {
		emf=Persistence.createEntityManagerFactory("MyJPA");
		em=emf.createEntityManager();
	}

	public void createEmployee(Employee emp) {
		EntityTransaction et=em.getTransaction();
		et.begin();
			em.persist(emp);
		et.commit();		
	}

	public Employee findEmp(int empNum) {
		return em.find(Employee.class,empNum);
		
	}

	public void updateEmp(Employee emp) {
		EntityTransaction et = em.getTransaction();
		et.begin();
		em.merge(emp);
		System.out.println("Employee updating");
		et.commit();
		
	}

	public Set<Employee> findAllEmpTest() {
		Query query = em.createQuery("from Employee");
		List<Employee> list = query.getResultList();
		Set<Employee> empSet = new HashSet(list);
		return empSet;
	}


	public void deleteEmp(int empNum) {
		EntityTransaction et = em.getTransaction();
		et.begin();
		Employee e = em.find(Employee.class, empNum);
		em.remove(e);
		System.out.println("Employee deleting");
		et.commit();
		
	}
	

}
