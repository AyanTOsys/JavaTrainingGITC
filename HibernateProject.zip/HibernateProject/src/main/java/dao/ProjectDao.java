package dao;
import java.util.Set;

import entity.Project;

public interface ProjectDao {
	void addProject(Project p);

	void modifyProject(Project p);

	void deleteProject(int pId);

	Project findProject(int pId);

	Set<Project> findAllProject();
}
