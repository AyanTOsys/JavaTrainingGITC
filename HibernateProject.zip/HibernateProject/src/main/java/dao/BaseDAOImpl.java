package dao;

import java.io.Serializable;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;


public class BaseDAOImpl implements BaseDAO {
	EntityManagerFactory emf;
	EntityManager em;
	
	public BaseDAOImpl(){
		emf=Persistence.createEntityManagerFactory("MyJPA");
		em=emf.createEntityManager();
	}
	
	public void persist(Object obj) {
		em=emf.createEntityManager();
		try {
			EntityTransaction tx=em.getTransaction();
			tx.begin();
				em.persist(obj);
			tx.commit();
		}
		finally {
			em.close();
		}
	}
	
	public void merge(Object obj) {
		em=emf.createEntityManager();
		try {
			EntityTransaction tx=em.getTransaction();
			tx.begin();
				em.merge(obj);
			tx.commit();
		}
		finally {
			em.close();
		}
	}
	
	public void remove(Object obj) {
		em=emf.createEntityManager();
		try {
			EntityTransaction tx=em.getTransaction();
			tx.begin();
				em.remove(obj);
			tx.commit();
		}
		finally {
			em.close();
		}
	}
	
	public <E>E find(Class<E> className, Serializable primaryKey) {
		
		em=emf.createEntityManager();
		try {
			E e=em.find(className, primaryKey);
			return e;
		}
		finally {
			em.close();
		}
	}
	public <E> List<E> findAll(String entityName) {
		
		em=emf.createEntityManager();
		try {
			Query query=em.createQuery("from "+entityName);
			return query.getResultList();
		}
		finally {
			em.close();
		}
	}
	
}
