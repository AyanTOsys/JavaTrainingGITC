package dao;

import java.io.Serializable;
import java.util.List;

public interface BaseDAO {
	public void persist(Object obj);
	public void merge(Object obj);
	public void remove(Object obj);
	public <E>E find(Class<E> className, Serializable primaryKey);
	public <E> List<E> findAll(String entityName);
}
