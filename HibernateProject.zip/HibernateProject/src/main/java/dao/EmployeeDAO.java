package dao;
import java.util.Set;

import entity.Employee;

public interface EmployeeDAO {
	public void createEmployee(Employee emp);
	public Employee findEmp(int empNum);
	public void updateEmp(Employee emp);
	public void deleteEmp(int empNum);
	Set<Employee> findAllEmpTest();
}
