package entity;

import java.time.LocalDate;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="pancard_tbl")
public class PanCard {
	@Id
	@Column(name="pancard_no",length=10)
	private String pancardNo;
	
	@Column(name="pancardholder_name")
	private String panholderName;
	
	@Column(name="dob")
	private LocalDate dateofBirth;
	
	@Column(name="pancardholder_fathername")
	private String panholderFatherName;
	
	@OneToOne(cascade=CascadeType.PERSIST)
	private Employee emp;

	public String getPancardNo() {
		return pancardNo;
	}

	public void setPancardNo(String pancardNo) {
		this.pancardNo = pancardNo;
	}

	public String getPanholderName() {
		return panholderName;
	}

	public void setPanholderName(String panholderName) {
		this.panholderName = panholderName;
	}

	public LocalDate getDateofBirth() {
		return dateofBirth;
	}

	public void setDateofBirth(LocalDate dateofBirth) {
		this.dateofBirth = dateofBirth;
	}

	public String getPanholderFatherName() {
		return panholderFatherName;
	}

	public void setPanholderFatherName(String panholderFatherName) {
		this.panholderFatherName = panholderFatherName;
	}

	public Employee getEmp() {
		return emp;
	}

	public void setEmp(Employee emp) {
		this.emp = emp;
	}
		
}
