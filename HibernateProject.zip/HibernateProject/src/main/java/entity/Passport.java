package entity;
import java.time.LocalDate;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="passport_tbl2")
public class Passport {
	@Id
	@GeneratedValue
	private int passportID;
	
	
	@Column(name="passport_issue_dt",length=20)
	private LocalDate passportIssuedDate;
	
	@Column(name="passport_expiry_dt",length=20)
	private LocalDate passportExpiryDate;
	
	@Column(name="passport_issued_by",length=20)
	private String issuedBy;
	
	@OneToOne(cascade=CascadeType.PERSIST)
	private Employee emp;
	

	public Employee getEmp() {
		return emp;
	}
	public void setEmp(Employee emp) {
		this.emp = emp;
	}
	public int getPassportID() {
		return passportID;
	}
	public void setPassportID(int passportID) {
		this.passportID = passportID;
	}

	public LocalDate getPassportIssuedDate() {
		return passportIssuedDate;
	}
	public void setPassportIssuedDate(LocalDate passportIssuedDate) {
		this.passportIssuedDate = passportIssuedDate;
	}
	public LocalDate getPassportExpiryDate() {
		return passportExpiryDate;
	}
	public void setPassportExpiryDate(LocalDate passportExpiryDate) {
		this.passportExpiryDate = passportExpiryDate;
	}
	public String getIssuedBy() {
		return issuedBy;
	}
	public void setIssuedBy(String issuedBy) {
		this.issuedBy = issuedBy;
	}
	@Override
	public String toString() {
		return "Passport [passportID=" + passportID +  ", passportIssuedDate="
				+ passportIssuedDate + ", passportExpiryDate=" + passportExpiryDate + ", issuedBy=" + issuedBy + "]";
	}	
}
