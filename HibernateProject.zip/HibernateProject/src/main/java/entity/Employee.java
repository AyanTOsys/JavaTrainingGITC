package entity;
import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="emp_tbl2")
public class Employee {
	
	@Id
	@GeneratedValue
	@Column(name="emp_no")
	private int employeeNumber;
	
	@Column(name="emp_name",length=20)
	private String name;
	
	@Column(name="emp_job",length=20)
	private String job;
	
	@Column(name="emp_doj")
	private LocalDate joiningDate;
	
	@Column(name="emp_sal")
	private double salary;
	
	@Column(name="emp_age")
	private Integer age;
	
	@OneToOne
	private Passport passport;
	
	@OneToOne
	private PanCard pancard;
	
	@ManyToOne
	@JoinColumn(name="deptno")
	Department dept;
	
	@OneToMany(mappedBy="emp",cascade=CascadeType.ALL)
	Set<Address> addrList=new HashSet<Address>();
	
	@ManyToMany
	@JoinTable(name="EmployeeProjectLink",joinColumns = {@JoinColumn(name="eid")},inverseJoinColumns = {@JoinColumn(name="pid")})
	Set<Project> projList=new HashSet<Project>();
	


	public Set<Project> getProjList() {
		return projList;
	}

	public void setProjList(Set<Project> projList) {
		this.projList = projList;
	}

	public Set<Address> getAddrList() {
		return addrList;
	}

	public void setAddrList(Set<Address> addrList) {
		this.addrList = addrList;
	}

	public Employee(String name, String job, LocalDate joiningDate, double salary, Integer age,
			Passport passport, Department dept,PanCard pancard) {
		
		this.name = name;
		this.job = job;
		this.joiningDate = joiningDate;
		this.salary = salary;
		this.age = age;
		this.passport = passport;
		this.dept = dept;
		this.pancard=pancard;
	}
	
	public Employee(String name, String job, LocalDate joiningDate, double salary, Integer age,
			Passport passport, Department dept) {
		
		this.name = name;
		this.job = job;
		this.joiningDate = joiningDate;
		this.salary = salary;
		this.age = age;
		this.passport = passport;
		this.dept = dept;
		
	}
	

	
	public Employee(int employeeNumber, String name, String job, LocalDate joiningDate, double salary, Integer age,
			Set<Address> addrList) {
		super();
		this.employeeNumber = employeeNumber;
		this.name = name;
		this.job = job;
		this.joiningDate = joiningDate;
		this.salary = salary;
		this.age = age;
		this.addrList = addrList;
	}

	public Employee(String name, String job, LocalDate joiningDate, double salary, Integer age) {
		super();
		this.name = name;
		this.job = job;
		this.joiningDate = joiningDate;
		this.salary = salary;
		this.age = age;
	}

	public PanCard getPancard() {
		return pancard;
	}
	public void setPancard(PanCard pancard) {
		this.pancard = pancard;
	}
	public Department getDept() {
		return dept;
	}
	public void setDept(Department dept) {
		this.dept = dept;
	}
	public Integer getAge() {
		return age;
	}
	public void setAge(Integer age) {
		this.age = age;
	}
	public Passport getPassport() {
		return passport;
	}
	public void setPassport(Passport passport) {
		this.passport = passport;
	}
	public Employee() {
		super();
		System.out.println("Employee created...");
	}
	public int getEmployeeNumber() {
		return employeeNumber;
	}
	public void setEmployeeNumber(int employeeNumber) {
		this.employeeNumber = employeeNumber;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getJob() {
		return job;
	}
	public void setJob(String job) {
		this.job = job;
	}
	public LocalDate getJoiningDate() {
		return joiningDate;
	}
	public void setJoiningDate(LocalDate joiningDate) {
		this.joiningDate = joiningDate;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}	
}

