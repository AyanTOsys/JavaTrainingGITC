package entity;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name="proj_tbl")
public class Project {
	
	@Id
	@GeneratedValue
	@Column(name="proj_id")
	private int projectID;
	
	@Column(name="proj_name",length=20)
	private String projectName;
	
	@Column(name="proj_deadline",length=20)
	private LocalDate deadline;
	
	@ManyToMany
	@JoinTable(name="EmployeeProjectLink",joinColumns = {@JoinColumn(name="pid")},inverseJoinColumns = {@JoinColumn(name="eid")})
	Set<Employee> emp=new HashSet<Employee>();
	
	public int getProjectID() {
		return projectID;
	}
	public Set<Employee> getEmp() {
		return emp;
	}
	public void setEmp(Set<Employee> emp) {
		this.emp = emp;
	}
	public void setProjectID(int projectID) {
		this.projectID = projectID;
	}
	public String getProjectName() {
		return projectName;
	}
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
	public LocalDate getDeadline() {
		return deadline;
	}
	public void setDeadline(LocalDate deadline) {
		this.deadline = deadline;
	}
	@Override
	public String toString() {
		return "Project [projectID=" + projectID + ", projectName=" + projectName + ", deadline=" + deadline + "]";
	}
}
