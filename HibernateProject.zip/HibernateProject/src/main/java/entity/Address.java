package entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="address_tbl")
public class Address {
	
	@Id
	@GeneratedValue
	@Column(name="add_id")
	int addressID;
	
	@Column(name="add_area")
	private String area;
	
	@Column(name="add_street")
	private String street;
	
	@Column(name="add_st")
	private String state;
	
	@Column(name="add_ct")
	private String city;
	
	@Column(name="add_country")
	private String country;
	
	@Column(name="add_pin")
	private int pin;
	
	@Column(name="add_type")
	String addressType;
	
	@ManyToOne
	@JoinColumn(name="address")
	Employee emp;
	
	public Employee getEmp() {
		return emp;
	}
	public void setEmp(Employee emp) {
		this.emp = emp;
	}
	public int getAddressID() {
		return addressID;
	}
	public void setAddressID(int addressID) {
		this.addressID = addressID;
	}
	public String getArea() {
		return area;
	}
	public void setArea(String area) {
		this.area = area;
	}
	public String getStreet() {
		return street;
	}
	public void setStreet(String street) {
		this.street = street;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public int getPin() {
		return pin;
	}
	public void setPin(int pin) {
		this.pin = pin;
	}
	public String getAddressType() {
		return addressType;
	}
	public void setAddressType(String addressType) {
		this.addressType = addressType;
	}
	@Override
	public String toString() {
		return "Address [addressID=" + addressID + ", area=" + area + ", street=" + street + ", state=" + state
				+ ", city=" + city + ", country=" + country + ", pin=" + pin + ", addressType=" + addressType + "]";
	}
	
}
