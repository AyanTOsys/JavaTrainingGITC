import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class SelectSingleRecordTest {

	public static void main(String[] args) {
		try {
			//load drive
			DriverManager.registerDriver(new org.hsqldb.jdbc.JDBCDriver());
			//aquire connection
			Connection conn = DriverManager.getConnection("jdbc:hsqldb:hsql://localhost/xdb","SA","");
			//make statement
			Statement st=conn.createStatement();
			//result
			ResultSet result = st.executeQuery("select * from FRIENDS WHERE FRIEND_ID=?");
			
			Scanner scan=new Scanner(System.in);
			System.out.println("Enter friend id:");
			int fid=scan.nextInt();
			
			if(result.next()) {
				int x = result.getInt(1);
				String y = result.getString(2);
				String z = result.getString(3);
				System.out.println("Friend ID: "+x+", Friend Name: "+y+", Friend Type: "+z);
				System.out.println("---------");
			}
			else
				System.out.println("Friend not found");
			st.close();
			conn.close();
		}
		catch(SQLException e) {
			System.out.println("Some database problems.."+e);
		}
	}

}
