import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class DeleteTest {

	public static void main(String[] args) {
		try {
			DriverManager.registerDriver(new org.hsqldb.jdbc.JDBCDriver());
			Connection conn=DriverManager.getConnection("jdbc:hsqldb:hsql://localhost/xdb","SA","");
			PreparedStatement pst=conn.prepareStatement("DELETE FROM FRIENDS WHERE FRIEND_ID=?");
			
			Scanner scan1=new Scanner(System.in);
						
			System.out.println("Enter friend id:");
			int fid=scan1.nextInt();
			
			pst.setInt(1,fid);
			
			int rowsUpdated = pst.executeUpdate();
			System.out.println("Number of rows updated:"+rowsUpdated);
			
			pst.close();
			conn.close();
		}
		catch(SQLException e) {
			System.out.println("Some sql problems..");
		}
	}

}
