package com.sbi.project.layer4;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sbi.project.layer2.Account;
import com.sbi.project.layer2.Applicant;
import com.sbi.project.layer2.ApplicationStatus;
import com.sbi.project.layer3.AccountRepository;
import com.sbi.project.layer3.ApplicantRepository;

@Service
public class AccountServiceImpl implements AccountService {

	@Autowired
	AccountRepository accRepo;
	
	@Autowired
	ApplicantRepository appRepo;
	
	public void openBankAccountService(int applicantId) {
		Applicant applicant = appRepo.findApplication(applicantId);
		
		if(applicant!=null) {
			Account account=new Account();
			account.setAccountHolder(applicant.getApplicantName());
			account.setAccountBalance(5000);
			account.setApplicant(applicant);
			applicant.setApplicationStatus(ApplicationStatus.APPROVED);
			appRepo.modifyApplication(applicant);
			accRepo.createAccount(account);
		}
		
		else
		{
			throw new RuntimeException("Applicant id not found"+applicantId);
		}
	}

}
