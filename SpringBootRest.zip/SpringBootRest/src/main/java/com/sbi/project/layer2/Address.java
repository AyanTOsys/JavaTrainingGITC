package com.sbi.project.layer2;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name="address_tbl")
public class Address {
	
	@Id
	@GeneratedValue
	@Column(name="add_id")
	private int addressid;
	@Column(name="add_area")
	private String area;
	@Column(name="add_street")
	private String street;
	@Column(name="add_st")
	private String state;
	@Column(name="add_ct")
	private String city;
	@Column(name="add_country")
	private String country;
	@Column(name="add_pin")
	private int pin;
	@Column(name="add_type")
	private String addresstype;
	
	@ManyToOne
	@JoinColumn(name="applicant_id")
	Applicant applicant;

	public int getAddressid() {
		return addressid;
	}

	public void setAddressid(int addressid) {
		this.addressid = addressid;
	}

	public String getArea() {
		return area;
	}

	public void setArea(String area) {
		this.area = area;
	}

	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public int getPin() {
		return pin;
	}

	public void setPin(int pin) {
		this.pin = pin;
	}

	public String getAddresstype() {
		return addresstype;
	}

	public void setAddresstype(String addresstype) {
		this.addresstype = addresstype;
	}

	@JsonIgnore
	public Applicant getApplicant() {
		return applicant;
	}

	public void setApplicant(Applicant applicant) {
		this.applicant = applicant;
	}

	@Override
	public String toString() {
		return "Address [addressid=" + addressid + ", area=" + area + ", street=" + street + ", state=" + state
				+ ", city=" + city + ", country=" + country + ", pin=" + pin + ", addresstype=" + addresstype
				+ ", applicant=" + applicant + "]";
	}

	
		
}
