package com.sbi.project.layer3;

import java.io.Serializable;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

@Repository
public class BaseRepositoryImpl implements BaseRepository{
	
	@PersistenceContext
	EntityManager em;
	
	public BaseRepositoryImpl(){

	}
	
	@Transactional
	public void persist(Object obj) {
	
		em.persist(obj);
	}
	
	@Transactional
	public void merge(Object obj) {
		em.merge(obj);
	}
	
	@Transactional
	public void remove(Object obj) {
		em.remove(obj);
	}
	
	@Transactional
	public <E>E find(Class<E> className, Serializable primaryKey) {

		E e=em.find(className, primaryKey);
		return e;
	}
	

	@Override
	public <E> List<E> findAll(String entityName, Class<E> className) {
		TypedQuery<E> typedQuery=em.createQuery("from "+entityName, className);
		return typedQuery.getResultList();
	}
	
}
