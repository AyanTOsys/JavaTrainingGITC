package com.sbi.project.layer5;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/greetings")
public class GreetingController {
	
	@RequestMapping("/greet")
	public String greetingMessege() {
		return "Welcome to spring web rest based application";
	}
	
	@RequestMapping("/regards")
	public String regardMessege() {
		return "Welcome to spring web rest based application..Regards!!";
	}
	
	@RequestMapping("/boot")
	public String bootMessege() {
		return "Welcome to spring web rest based application..now booting!!";
	}
	

}
