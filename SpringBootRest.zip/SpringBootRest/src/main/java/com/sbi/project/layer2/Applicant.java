package com.sbi.project.layer2;

import java.security.Policy;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

@Component
@Entity
@Table(name="applicant_tbl")
public class Applicant {
	@Id
	@GeneratedValue
	@Column(name="applicant_id")
	private int applicantId;
	
	@Column(name="account_type")
	private String accountType;
	
	@Column(name="applicant_name")
	private String applicantName;
	
	@Column(name="applicant_dob")
	private LocalDate dateofBirth;
	
	@Column(name="applicant_fathername")
	private String applicantFatherName;
	
	@Column(name="applicant_mobile")
	private int mobileNumber;
	
	@Column(name="adhaar_number")
	private double adhaarNumber;
	
	@Column(name="pan_number")
	private String panNumber;
	
	@Column(name="married_status")
	private String married;
	
	@Column(name="applicant_photo")
	private String photo;
	
	@Column(name="applicant_occupation")
	private String occupation;
	
	@Column(name="applicant_income")
	private float annualIncome;

	@OneToMany(mappedBy="applicant",cascade=CascadeType.ALL,fetch=FetchType.EAGER)
	List<Address> addressList=new ArrayList<Address>();
	
	@Column(name="applicationstatus")
	private String applicationStatus;
	
	public String getApplicationStatus() {
		return applicationStatus;
	}

	public void setApplicationStatus(String applicationStatus) {
		this.applicationStatus = applicationStatus;
	}

	public float getAnnualIncome() {
		return annualIncome;
	}

	public void setAnnualIncome(float annualIncome) {
		this.annualIncome = annualIncome;
	}

	
	public int getApplicantId() {
		return applicantId;
	}

	public void setApplicantId(int applicantId) {
		this.applicantId = applicantId;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public String getApplicantName() {
		return applicantName;
	}

	public void setApplicantName(String applicantName) {
		this.applicantName = applicantName;
	}

	public LocalDate getDateofBirth() {
		return dateofBirth;
	}

	public void setDateofBirth(LocalDate dateofBirth) {
		this.dateofBirth = dateofBirth;
	}

	public String getApplicantFatherName() {
		return applicantFatherName;
	}

	public void setApplicantFatherName(String applicantFatherName) {
		this.applicantFatherName = applicantFatherName;
	}

	public int getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(int mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public double getAdhaarNumber() {
		return adhaarNumber;
	}

	public void setAdhaarNumber(double adhaarNumber) {
		this.adhaarNumber = adhaarNumber;
	}

	public String getPanNumber() {
		return panNumber;
	}

	public void setPanNumber(String panNumber) {
		this.panNumber = panNumber;
	}

	public String getMarried() {
		return married;
	}

	public void setMarried(String married) {
		this.married = married;
	}

	public String getPhoto() {
		return photo;
	}

	public void setPhoto(String photo) {
		this.photo = photo;
	}

	public String getOccupation() {
		return occupation;
	}

	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}

	public List<Address> getAddressList() {
		return addressList;
	}

	public void setAddressList(List<Address> addressList) {
		this.addressList = addressList;
	}

	@Override
	public String toString() {
		return "Applicant [applicantId=" + applicantId + ", accountType=" + accountType + ", applicantName="
				+ applicantName + ", dateofBirth=" + dateofBirth + ", applicantFatherName=" + applicantFatherName
				+ ", mobileNumber=" + mobileNumber + ", adhaarNumber=" + adhaarNumber + ", panNumber=" + panNumber
				+ ", married=" + married + ", photo=" + photo + ", occupation=" + occupation + ", annualIncome="
				+ annualIncome + ", addressList=" + addressList + ", applicationStatus=" + applicationStatus + "]";
	}


}
