package com.sbi.project.layer3;

import java.io.Serializable;
import java.util.List;

import org.springframework.stereotype.Repository;
@Repository
public interface BaseRepository {
	public void persist(Object obj);
	public void merge(Object obj);
	public void remove(Object obj);
	public <E>E find(Class<E> className, Serializable primaryKey);
	public <E> List<E> findAll(String entityName);
}
