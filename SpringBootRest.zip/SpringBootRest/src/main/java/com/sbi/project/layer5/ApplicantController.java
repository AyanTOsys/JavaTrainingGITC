package com.sbi.project.layer5;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sbi.project.layer2.Applicant;
import com.sbi.project.layer4.ApplicantService;
import com.sbi.project.layer4.ApplicantServiceImpl;

@RestController
@RequestMapping("/applicants")
public class ApplicantController {
	
	@Autowired
	ApplicantService applicantService=new ApplicantServiceImpl();
	
	static List<Applicant> applicantList;
	
	public ApplicantController() {
		System.out.println("ApplicantController ctor().....");		
	}
	
	@RequestMapping("/getAllApplicants")
	public List<Applicant> getAllApplicants() {
		return applicantService.getAllApplicant();
		
	}
	
	@RequestMapping("/getAllApplicants/{applicantId}")
	public Applicant getApplicant(@PathVariable("applicantId") int applicantIdToSearch) {
		boolean applFound=false;
		Applicant applicant=null;
		applicantList=applicantService.getAllApplicant();
		
		for (int i=0;i<applicantList.size();i++) {
			applicant=applicantList.get(i);
			if(applicant.getApplicantId()==applicantIdToSearch) {
				applFound=true;
				break;
			}
		}

		
		if(applFound==true)
			return applicant;
		else
			return null;
	}
	
	@RequestMapping("/deleteApplicant/{applicantId}")
	public String deleteApplicant(@PathVariable("applicantId") int applicantIdToDelete) {
		boolean applFound=false;
		Applicant applicant=null;
		applicantList=applicantService.getAllApplicant();
		
		for (int i=0;i<applicantList.size();i++) {
			applicant=applicantList.get(i);
			if(applicant.getApplicantId()==applicantIdToDelete) {
				applFound=true;
				applicantList.remove(i);
				break;
			}
		}

		
		if(applFound==true)
			return "Applicant deleted: "+applicantIdToDelete;
		else
			return "Applicant not found";
	}
	
	@RequestMapping("/updateApplicant")
	public String updateApplicant(@RequestBody Applicant applObjToUpdate) {
		boolean applFound=false;
		Applicant applicant=null;
		applicantList=applicantService.getAllApplicant();
		for (int i=0;i<applicantList.size();i++) {
			applicant=applicantList.get(i);
			if(applicant.getApplicantId()==applObjToUpdate.getApplicantId()) {
				applFound=true;
				applicantList.remove(i);
				applicantList.add(applObjToUpdate);
				break;
			}
		}

		if(applFound==true)
			return "Applicant object updated "+applObjToUpdate.getApplicantId();
		else
			return "Applicant not found";
	}
	
	@RequestMapping("/addApplicant") 
	public String addEmployee(@RequestBody Applicant applObjectToAdd) {
		
		boolean applFound=false;
		
		Applicant applObject = null;
		
		applicantList=applicantService.getAllApplicant();
		
		for(int i=0;i<applicantList.size();i++) {
			applObject = applicantList.get(i);
			if(applObject.getApplicantId() == applObjectToAdd.getApplicantId()) {
				applFound = true;
				break;
			}
		}
		if(applFound==true)	
			return "Applicant with this employeeNumber already exists!!!"; 
		else {
			applicantList.add(applObjectToAdd);
			return "Applicant Object added succesfully : "+applObjectToAdd.getApplicantId();
		}
	}
/*	
	

	@RequestMapping("/addEmp") 
	public String addEmployee(@RequestBody Employee employeeObjectToAdd) {
		
		boolean employeeFound=false;
		Employee employeeObject = null;
		for(int i=0;i<empList.size();i++) {
			employeeObject = empList.get(i);
			if(employeeObject.getEmployeeNumber() == employeeObjectToAdd.getEmployeeNumber()) {
				employeeFound = true;
				break;
			}
		}
		if(employeeFound==true)	
			return "Employee with this employeeNumber already exists!!!"; 
		else {
			empList.add(employeeObjectToAdd);
			return "Employee Object added succesfully : ";
		}
				
	}*/
}
