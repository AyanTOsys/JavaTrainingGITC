package com.sbi.project.layer5;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sbi.project.layer2.Applicant;
import com.sbi.project.layer4.ApplicantService;
import com.sbi.project.layer4.ApplicantServiceImpl;
@CrossOrigin
@RestController
@RequestMapping("/applicants")
public class ApplicantController {
	
	@Autowired
	ApplicantService applicantService=new ApplicantServiceImpl();
	
	static List<Applicant> applicantList;
	
	public ApplicantController() {
		System.out.println("ApplicantController ctor().....");		
	}
	
	@RequestMapping("/getAllApplicants")
	public List<Applicant> getAllApplicants() {
		return applicantService.getAllApplicant();
		
	}
	
	@RequestMapping("/getAllApplicants/{applicantId}")
	public Applicant getApplicant(@PathVariable("applicantId") int applicantIdToSearch) {
		return applicantService.getApplicant(applicantIdToSearch);
	}
	
	@RequestMapping("/deleteApplicant/{applicantId}")
	public String deleteApplicant(@PathVariable("applicantId") int applicantIdToDelete) {
		applicantService.deleteApplicant(applicantIdToDelete);
		return "Deleted appliacnt id: "+applicantIdToDelete;
	}
	
	@RequestMapping("/updateApplicant")
	public String updateApplicant(@RequestBody Applicant applObjToUpdate) {
		applicantService.updateApplicant(applObjToUpdate);
		return "Updated applicant id: "+applObjToUpdate.getApplicantId();
	}
	
	@PostMapping("/addApplicant") 
	public String addApplicant(@RequestBody Applicant applObjectToAdd) {
		
		applicantService.createApplication(applObjectToAdd);
		return "Applicant id: "+applObjectToAdd.getApplicantId()+" successfully added";
	}

}
