package com.sbi.project.layer4;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sbi.project.layer2.Address;
import com.sbi.project.layer2.Applicant;
import com.sbi.project.layer2.ApplicationStatus;
import com.sbi.project.layer3.ApplicantRepository;
import com.sbi.project.layer3.ApplicantRepositoryImpl;

@Service
public class ApplicantServiceImpl implements ApplicantService {

	@Autowired
	ApplicantRepository appRepo=new ApplicantRepositoryImpl();
	
	@Override
	public void createApplication(Applicant applicant) {
		List<Address> addrList=applicant.getAddressList();
		for (Address address : addrList) {
			address.setApplicant(applicant);
		}
		
		applicant.setApplicationStatus(ApplicationStatus.APPLIED);
	
		appRepo.createApplication(applicant);
		System.out.println("ApplicantServiceImpl()....");

	}

	@Override
	public List<Applicant> getAllApplicant() {
		// TODO Auto-generated method stub
		return appRepo.findAllApplicants();
	}

	@Override
	public void deleteApplicant(int applicantId) {
		boolean applicantFound=false;
		Applicant appObject = null;
		
		List<Applicant> applist= appRepo.findAllApplicants();
		for(int i=0;i<applist.size();i++) {
			appObject = applist.get(i);
			if(appObject.getApplicantId() == applicantId) {
				applicantFound = true;
				break;
			}
		}
		if(applicantFound==true)	
			appRepo.removeApplication(applicantId);	
		else	
			throw new RuntimeException("Applicant Not Found");
		
	}

	@Override
	public Applicant getApplicant(int applicantId) {
		boolean applFound=false;
		Applicant applicant=null;
		
		
		List<Applicant> applist= appRepo.findAllApplicants();
		
		for(int i=0;i<applist.size();i++) {
			applicant = applist.get(i);
			if(applicant.getApplicantId() == applicantId) {
				applFound = true;
				break;
			}
		}
		
		
		if(applFound==true)
			return applicant;
		else
			return null;
	}

	@Override
	public void updateApplicant(Applicant applicant) {
		boolean applFound=false;
		Applicant appl=null;
		List<Applicant> applist= appRepo.findAllApplicants();
		for (int i=0;i<applist.size();i++) {
			appl=applist.get(i);
			if(appl.getApplicantId()==applicant.getApplicantId()) {
				applFound=true;
				
				break;
			}
		}

		if(applFound==true)
			appRepo.modifyApplication(applicant);
		else
			throw new RuntimeException("Applicant Not Found");
		
	}
	
	

}
