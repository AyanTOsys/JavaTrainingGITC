package com.sbi.project.layer4;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sbi.project.layer2.Applicant;
import com.sbi.project.layer3.ApplicantRepository;
import com.sbi.project.layer3.ApplicantRepositoryImpl;

@Service
public class ApplicantServiceImpl implements ApplicantService {

	@Autowired
	ApplicantRepository appRepo=new ApplicantRepositoryImpl();
	
	@Override
	public void createApplication(Applicant applicant) {
		appRepo.createApplication(applicant);
		System.out.println("ApplicantServiceImpl()....");

	}

	@Override
	public List<Applicant> getAllApplicant() {
		// TODO Auto-generated method stub
		return appRepo.findAllApplicants();
	}

}
