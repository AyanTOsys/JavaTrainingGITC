package com.sbi.project.layer5;
import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;

//import javax.persistence.CascadeType;
//import javax.persistence.Column;
//import javax.persistence.Entity;
//import javax.persistence.GeneratedValue;
//import javax.persistence.Id;
//import javax.persistence.JoinColumn;
//import javax.persistence.JoinTable;
//import javax.persistence.ManyToMany;
//import javax.persistence.ManyToOne;
//import javax.persistence.OneToMany;
//import javax.persistence.OneToOne;
//import javax.persistence.Table;


public class Employee {

	private int employeeNumber;

	private String name;

	private String job;

	private LocalDate joiningDate;

	private double salary;

	private Integer age;

	public Employee(int employeeNumber, String name, String job, LocalDate joiningDate, double salary, Integer age) {
		super();
		this.employeeNumber = employeeNumber;
		this.name = name;
		this.job = job;
		this.joiningDate = joiningDate;
		this.salary = salary;
		this.age = age;
	}

	public Employee() {
		super();
	}

	public int getEmployeeNumber() {
		return employeeNumber;
	}

	public void setEmployeeNumber(int employeeNumber) {
		this.employeeNumber = employeeNumber;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getJob() {
		return job;
	}

	public void setJob(String job) {
		this.job = job;
	}

	public LocalDate getJoiningDate() {
		return joiningDate;
	}

	public void setJoiningDate(LocalDate joiningDate) {
		this.joiningDate = joiningDate;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public Integer getAge() {
		return age;
	}

	public void setAge(Integer age) {
		this.age = age;
	}

	@Override
	public String toString() {
		return "Employee [employeeNumber=" + employeeNumber + ", name=" + name + ", job=" + job + ", joiningDate="
				+ joiningDate + ", salary=" + salary + ", age=" + age + "]";
	}


}

