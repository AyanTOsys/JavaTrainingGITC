package com.sbi.project.layer2;

public interface ApplicationStatus {
	String APPLIED="APPLIED";
	String IN_PROGRESS="IN PROGRESS";
	String APPROVED="APPROVED";
	String REJECTED="REJECTED";
}
