package com.sbi.project.layer5;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/emps")
public class EmployeeController {
	
	ArrayList<Employee> empList=new ArrayList<Employee>();
	
	
	public EmployeeController() {
		Employee emp1=new Employee(7839,"KING","PRESIDENT",LocalDate.of(2020, 10, 2),78000,39);
		Employee emp2=new Employee(7840,"JOE","ANALYST",LocalDate.of(2021, 10, 2),11000,30);
		Employee emp3=new Employee(7841,"BARTON","SALESMAN",LocalDate.of(2020, 10, 2),18000,30);
		empList.add(emp1); empList.add(emp2); empList.add(emp3);
	}
	
	@RequestMapping("/getAllEmps")
	public List<Employee> getAllEmployees() {
		return empList;
	}
	
	@RequestMapping("/getAllEmps/{employeeNumber}")
	public Employee getEmployee(@PathVariable("employeeNumber") int employeeNumToSearch) {
		boolean empFound=false;
		Employee emp=null;
		for (int i=0;i<empList.size();i++) {
			emp=empList.get(i);
			if(emp.getEmployeeNumber()==employeeNumToSearch) {
				empFound=true;
				break;
			}
		}
//		for (Employee employee : empList) {
//			int empId=employee.getEmployeeNumber();
//			if(empId==employeeNumToSearch) {
//				empFound=true;
//				break;
//			}
//		}
		
		if(empFound==true)
			return emp;
		else
			return null;
	}
	
	@RequestMapping("/deleteemp/{employeeNumber}")
	public String deleteEmployee(@PathVariable("employeeNumber") int employeeNumToDelete) {
		boolean empFound=false;
		Employee emp=null;
		for (int i=0;i<empList.size();i++) {
			emp=empList.get(i);
			if(emp.getEmployeeNumber()==employeeNumToDelete) {
				empFound=true;
				empList.remove(i);
				break;
			}
		}

		if(empFound==true)
			return "Emp object deleted"+employeeNumToDelete;
		else
			return "Employee not found";
	}
	
	@RequestMapping("/updateEmp")
	public String updateEmployee(@RequestBody Employee employeeObjToUpdate) {
		boolean empFound=false;
		Employee emp=null;
		for (int i=0;i<empList.size();i++) {
			emp=empList.get(i);
			if(emp.getEmployeeNumber()==employeeObjToUpdate.getEmployeeNumber()) {
				empFound=true;
				empList.remove(i);
				empList.add(employeeObjToUpdate);
				break;
			}
		}

		if(empFound==true)
			return "Emp object updated "+employeeObjToUpdate.getEmployeeNumber();
		else
			return "Employee not found";
	}
	
	@RequestMapping("/addEmp") 
	public String addEmployee(@RequestBody Employee employeeObjectToAdd) {
		
		boolean employeeFound=false;
		Employee employeeObject = null;
		for(int i=0;i<empList.size();i++) {
			employeeObject = empList.get(i);
			if(employeeObject.getEmployeeNumber() == employeeObjectToAdd.getEmployeeNumber()) {
				employeeFound = true;
				break;
			}
		}
		if(employeeFound==true)	
			return "Employee with this employeeNumber already exists!!!"; 
		else {
			empList.add(employeeObjectToAdd);
			return "Employee Object added succesfully : ";
		}
				
	}
}
