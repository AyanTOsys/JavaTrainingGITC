package com.sbi.project.layer4;

import java.util.List;

import org.springframework.stereotype.Service;

import com.sbi.project.layer2.Applicant;

@Service
public interface ApplicantService {
	void createApplication(Applicant applicant);
	List<Applicant> getAllApplicant();
	void deleteApplicant(int applicantId);
	Applicant getApplicant(int applicantId);
	void updateApplicant(Applicant applicant);
}
