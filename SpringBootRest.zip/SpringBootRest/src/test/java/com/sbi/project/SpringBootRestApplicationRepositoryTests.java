package com.sbi.project;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.sbi.project.layer2.Address;
import com.sbi.project.layer2.Applicant;
import com.sbi.project.layer2.ApplicationStatus;
import com.sbi.project.layer3.ApplicantRepository;

@SpringBootTest
class SpringBootRestApplicationRepositoryTests {

	@Autowired
	ApplicantRepository apprepo;
	@Test
	void loadAllApplicantTest() {
		List<Applicant> allApplicants=apprepo.findAllApplicants();
		Assertions.assertTrue(allApplicants!=null);
		for (Applicant applicant : allApplicants) {
			System.out.println("Applicant id:"+applicant.getApplicantId());
			System.out.println("Applicant name:"+applicant.getApplicantName());
			System.out.println("Applicant mobile:"+applicant.getMobileNumber());
			System.out.println("Applicant pan:"+applicant.getPanNumber());
			System.out.println("Applicant adhaar:"+applicant.getAdhaarNumber());
			System.out.println("Applicant DOB:"+applicant.getDateofBirth());
			System.out.println("Applicant annual income:"+applicant.getAnnualIncome());
			System.out.println("Applicant father name:"+applicant.getApplicantFatherName());
			System.out.println("Applicant occupation:"+applicant.getOccupation());
			System.out.println("Applicant photo:"+applicant.getPhoto());
			System.out.println("Applicant application status:"+applicant.getApplicationStatus());
			
			
			List<Address> addList=applicant.getAddressList();
			Assertions.assertTrue(addList!=null);
			for (Address address : addList) {
				System.out.println("****");
				System.out.println("Applicant address type:"+address.getAddresstype());
				System.out.println("Applicant address street:"+address.getStreet());
				System.out.println("Applicant address state:"+address.getState());
				System.out.println("****");
			}
			
			System.out.println("==================================================");
		}
	}
	
	@Test
	void loadSingleApplicantTest() {
		Applicant applicant=apprepo.findApplication(55);
		Assertions.assertTrue(applicant!=null);
		
		System.out.println("Applicant id:"+applicant.getApplicantId());
		System.out.println("Applicant name:"+applicant.getApplicantName());
		System.out.println("Applicant mobile:"+applicant.getMobileNumber());
		System.out.println("Applicant pan:"+applicant.getPanNumber());
		System.out.println("Applicant adhaar:"+applicant.getAdhaarNumber());
		System.out.println("Applicant DOB:"+applicant.getDateofBirth());
		System.out.println("Applicant annual income:"+applicant.getAnnualIncome());
		System.out.println("Applicant father name:"+applicant.getApplicantFatherName());
		System.out.println("Applicant occupation:"+applicant.getOccupation());
		System.out.println("Applicant photo:"+applicant.getPhoto());
		System.out.println("Applicant application status:"+applicant.getApplicationStatus());
			
		List<Address> addList=applicant.getAddressList();
		Assertions.assertTrue(addList!=null);
		for (Address address : addList) {
				System.out.println("****");
				System.out.println("Applicant address type:"+address.getAddresstype());
				System.out.println("Applicant address street:"+address.getStreet());
				System.out.println("Applicant address state:"+address.getState());
				System.out.println("****");
					
		}
	}
	
	@Test
	void modifyApplicantTest() {
		Applicant applicant=apprepo.findApplication(61);
		Assertions.assertTrue(applicant!=null);
		
		System.out.println("***************OLD STATUS************");
		System.out.println("Applicant id:"+applicant.getApplicantId());
		System.out.println("Applicant name:"+applicant.getApplicantName());
		System.out.println("Applicant mobile:"+applicant.getMobileNumber());
		System.out.println("Applicant pan:"+applicant.getPanNumber());
		System.out.println("Applicant adhaar:"+applicant.getAdhaarNumber());
		System.out.println("Applicant DOB:"+applicant.getDateofBirth());
		System.out.println("Applicant annual income:"+applicant.getAnnualIncome());
		System.out.println("Applicant father name:"+applicant.getApplicantFatherName());
		System.out.println("Applicant occupation:"+applicant.getOccupation());
		System.out.println("Applicant photo:"+applicant.getPhoto());
		System.out.println("Applicant application status:"+applicant.getApplicationStatus());
			
		List<Address> addList=applicant.getAddressList();
		Assertions.assertTrue(addList!=null);
		for (Address address : addList) {
				System.out.println("****");
				System.out.println("Applicant address type:"+address.getAddresstype());
				System.out.println("Applicant address street:"+address.getStreet());
				System.out.println("Applicant address state:"+address.getState());
				System.out.println("****");
					
		}
		
		applicant.setApplicationStatus(ApplicationStatus.IN_PROGRESS);
		applicant.setApplicantFatherName("ronty");
		
		System.out.println("***************NEW STATUS************");
		System.out.println("Applicant id:"+applicant.getApplicantId());
		System.out.println("Applicant name:"+applicant.getApplicantName());
		System.out.println("Applicant mobile:"+applicant.getMobileNumber());
		System.out.println("Applicant pan:"+applicant.getPanNumber());
		System.out.println("Applicant adhaar:"+applicant.getAdhaarNumber());
		System.out.println("Applicant DOB:"+applicant.getDateofBirth());
		System.out.println("Applicant annual income:"+applicant.getAnnualIncome());
		System.out.println("Applicant father name:"+applicant.getApplicantFatherName());
		System.out.println("Applicant occupation:"+applicant.getOccupation());
		System.out.println("Applicant photo:"+applicant.getPhoto());
		System.out.println("Applicant application status:"+applicant.getApplicationStatus());
			
		addList=applicant.getAddressList();
		Assertions.assertTrue(addList!=null);
		for (Address address : addList) {
				System.out.println("****");
				System.out.println("Applicant address type:"+address.getAddresstype());
				System.out.println("Applicant address street:"+address.getStreet());
				System.out.println("Applicant address state:"+address.getState());
				System.out.println("****");
					
		}
	}
	
	@Test
	void deleteApplicantTest() {
		
		apprepo.removeApplication(55);
	}
	
	@Test
	void createApplicantTest() {
		Applicant applicant=new Applicant();
		
		applicant.setApplicantName("Bill");
		applicant.setAccountType("savings");
		applicant.setAdhaarNumber(789745457999d);
		applicant.setApplicantFatherName("John");
		applicant.setAnnualIncome(10000000);
		applicant.setApplicationStatus(ApplicationStatus.APPLIED);
		applicant.setDateofBirth(LocalDate.of(1960,12,4));
		applicant.setMarried("married");
		applicant.setMobileNumber(7789521);
		applicant.setOccupation("business");
		applicant.setPanNumber("QWQEW7896F");
		applicant.setPhoto("assets/bill.jpg");
		
		Address permaddr=new Address();
		permaddr.setAddresstype("permanent");
		permaddr.setArea("Vashi");
		permaddr.setStreet("vashi");
		permaddr.setCity("NaviMumbai");
		permaddr.setState("Maha");
		permaddr.setCountry("India");
		permaddr.setApplicant(applicant);
		
		Address corraddr=new Address();
		corraddr.setAddresstype("correspondence");
		corraddr.setArea("Airoli");
		corraddr.setStreet("airoli");
		corraddr.setCity("NaviMumbai");
		corraddr.setState("Maha");
		corraddr.setCountry("India");
		corraddr.setApplicant(applicant);
		
		List<Address> addlist=new ArrayList<Address>();
		addlist.add(corraddr);
		addlist.add(permaddr);
		
		applicant.setAddressList(addlist);
		
		apprepo.createApplication(applicant);
	}

}
