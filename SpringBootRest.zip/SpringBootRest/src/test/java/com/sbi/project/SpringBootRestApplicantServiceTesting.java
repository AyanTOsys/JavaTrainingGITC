package com.sbi.project;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.sbi.project.layer2.Address;
import com.sbi.project.layer2.Applicant;
import com.sbi.project.layer2.ApplicationStatus;
import com.sbi.project.layer4.ApplicantService;

@SpringBootTest
public class SpringBootRestApplicantServiceTesting {
	
	@Autowired
	ApplicantService appService;
	@Autowired
	Applicant applicant;
	
	@Test
	List<Applicant> loadAllApplicantServiceTest() {
		return appService.getAllApplicant();
	}
	
	@Test
	void createApplicantServiceTest() {
		applicant.setApplicantName("Sachin");
		applicant.setAccountType("savings");
		applicant.setAdhaarNumber(789745457999d);
		applicant.setApplicantFatherName("Ramesh");
		applicant.setAnnualIncome(10000000);
		applicant.setApplicationStatus(ApplicationStatus.APPLIED);
		applicant.setDateofBirth(LocalDate.of(1960,12,4));
		applicant.setMarried("married");
		applicant.setMobileNumber(7789521);
		applicant.setOccupation("business");
		applicant.setPanNumber("WBCNW7896F");
		applicant.setPhoto("assets/sachin.jpg");
		
		Address permaddr=new Address();
		permaddr.setAddresstype("permanent");
		permaddr.setArea("Vashi");
		permaddr.setStreet("vashi");
		permaddr.setCity("NaviMumbai");
		permaddr.setState("Maha");
		permaddr.setCountry("India");
		permaddr.setPin(400706);
		permaddr.setApplicant(applicant);
		
		Address corraddr=new Address();
		corraddr.setAddresstype("correspondence");
		corraddr.setArea("Nerul");
		corraddr.setStreet("Nerul");
		corraddr.setCity("NaviMumbai");
		corraddr.setState("Maha");
		corraddr.setCountry("India");
		corraddr.setPin(400706);
		corraddr.setApplicant(applicant);
		
		List<Address> addlist=new ArrayList<Address>();
		addlist.add(corraddr);
		addlist.add(permaddr);
		
		applicant.setAddressList(addlist);
		applicant.setApplicationStatus(ApplicationStatus.APPLIED);
		
		appService.createApplication(applicant);
	}
}
