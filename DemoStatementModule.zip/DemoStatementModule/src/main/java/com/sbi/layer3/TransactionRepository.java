package com.sbi.layer3;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.sbi.layer2.Account;
import com.sbi.layer2.Transaction;

@Repository
public interface TransactionRepository {

	void createTransaction(Transaction trn);
	void modifyTransaction(Transaction trn);
	void removeTransaction(int trnId);
	Transaction findTransaction(Account acc);
	List<Transaction> findAllTransactions();
	List<Transaction> findTransactionsOfAccount(Account acc);

}
