package com.sbi.layer3;

import java.io.Serializable;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

@Repository
public class BaseRepositoryImpl implements BaseRepository {

	@PersistenceContext
	EntityManager entityManager;
	
	@Override
	public void persist(Object obj) {
		entityManager.persist(obj);

	}

	@Override
	public void merge(Object obj) {
		// TODO Auto-generated method stub

	}

	@Override
	public void remove(Object obj) {
		// TODO Auto-generated method stub

	}

	@Override
	public <E> E find(Class<E> className, Serializable primaryKey) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public <E> List<E> findAll(String entityName, Class<E> className) {
		Query query=entityManager.createQuery("from "+entityName);
		return query.getResultList();
	}

}
