package com.sbi.layer3;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.sbi.layer2.Account;
import com.sbi.layer2.Transaction;

@Repository
public class TransactionRepositoryImpl extends BaseRepositoryImpl implements TransactionRepository {

	@Override
	public void createTransaction(Transaction trn) {
		// TODO Auto-generated method stub

	}

	@Override
	public void modifyTransaction(Transaction trn) {
		// TODO Auto-generated method stub

	}

	@Override
	public void removeTransaction(int trnId) {
		// TODO Auto-generated method stub

	}

	@Override
	public Transaction findTransaction(Account acc) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Transaction> findAllTransactions() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Transaction> findTransactionsOfAccount(Account acc) {
		// TODO Auto-generated method stub
		return super.findAll("Transaction", Transaction.class);
	}

}
