package com.sbi.layer2;
import java.util.List;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import org.springframework.stereotype.Component;

@Component @Entity @Table(name="project_account2")
public class Account {
	
	@Id
	@GeneratedValue
	@Column(name="account_number")
	private Integer accountNumber;
	
	@Column(name="AccName")
	private String accountName;
	
	@Column(name="current_balance")
	private Float accountBalance;
	
	@OneToMany(mappedBy = "debitAccountNumber")
	private List<Transaction> accountTrns;
	
	public Integer getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(Integer accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	public Float getAccountBalance() {
		return accountBalance;
	}

	public void setAccountBalance(Float accountBalance) {
		this.accountBalance = accountBalance;
	}

	public List<Transaction> getAccountTrns() {
		return accountTrns;
	}

	public void setAccountTrns(List<Transaction> accountTrns) {
		this.accountTrns = accountTrns;
	}
	
}
