package com.sbi.layer2;

import java.sql.Timestamp;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

@Component
@Entity
@Table(name="project_transaction2")
public class Transaction {

	@Id
	@GeneratedValue
	@Column(name="transid")
	private Integer transactionId;

	@ManyToOne(targetEntity = Account.class,fetch = FetchType.EAGER)
	@JoinColumn(name="account_number")	
	@Column(name="dbacc")
	private Integer debitAccountNumber;
	
	@Column(name="CrAcc")
	private Integer creditAccountNumber;
	
	@Column(name="trtype")
	private String trnType;
	
	@Column(name="Tramt")
	private Float trnAmount;
	
	@Column(name="tdesc")
	private String trnDescription;
	
	@Column(name="trdate")
	private Timestamp trnDateTime;
	
	@Column(name="DbAccCurrbalance")
	private Float DbAccCurrentBalance;
	
	@Column(name="CrAccCurrbalance")
	private Float CrAccCurrbalance;
	
	public Integer getDebitAccountNumber() {
		return debitAccountNumber;
	}

	public void setDebitAccountNumber(Integer debitAccountNumber) {
		this.debitAccountNumber = debitAccountNumber;
	}

	public Integer getCreditAccountNumber() {
		return creditAccountNumber;
	}

	public void setCreditAccountNumber(Integer creditAccountNumber) {
		this.creditAccountNumber = creditAccountNumber;
	}

	public String getTrnType() {
		return trnType;
	}

	public void setTrnType(String trnType) {
		this.trnType = trnType;
	}

	public Float getTrnAmount() {
		return trnAmount;
	}

	public void setTrnAmount(Float trnAmount) {
		this.trnAmount = trnAmount;
	}

	public String getTrnDescription() {
		return trnDescription;
	}

	public void setTrnDescription(String trnDescription) {
		this.trnDescription = trnDescription;
	}

	public Timestamp getTrnDateTime() {
		return trnDateTime;
	}

	public void setTrnDateTime(Timestamp trnDateTime) {
		this.trnDateTime = trnDateTime;
	}

	public Integer getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(Integer transactionId) {
		this.transactionId = transactionId;
	}

	public Float getDbAccCurrentBalance() {
		return DbAccCurrentBalance;
	}

	public void setDbAccCurrentBalance(Float dbAccCurrentBalance) {
		DbAccCurrentBalance = dbAccCurrentBalance;
	}

	public Float getCrAccCurrbalance() {
		return CrAccCurrbalance;
	}

	public void setCrAccCurrbalance(Float crAccCurrbalance) {
		CrAccCurrbalance = crAccCurrbalance;
	}

}
