package com.sbi.project;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.sbi.layer2.Transaction;
import com.sbi.layer3.TransactionRepository;

@SpringBootTest
class TransactionRepoTesting {
	
	@Autowired
	TransactionRepository trnRepo;

	@Test
	void findAllTransactionRepoTest() {
		List<Transaction> trnList=trnRepo.findAllTransactions();
		
		for (Transaction transaction : trnList) {
			System.out.println("Transaction type  :"+transaction.getTrnType());
			System.out.println("Debit AC Number   :"+transaction.getDebitAccountNumber());
			System.out.println("Credit AC Number  :"+transaction.getCreditAccountNumber());
			System.out.println("Transaction amount:"+transaction.getTrnAmount());
			System.out.println("Transaction date  :"+transaction.getTrnDateTime());
			System.out.println("Debit AC balance  :"+transaction.getDbAccCurrentBalance());
			System.out.println("Credit AC balance :"+transaction.getCrAccCurrbalance());
		}
		System.out.println("============================================================");
	}

}
