package com.sbi.project.layer3;

import java.time.LocalDate;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.sbi.project.layer2.Transaction;



@Repository
public class TransactionRepositoryImpl extends BaseRepositoryImpl implements TransactionRepository {
	
//	EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("MyJPA"); 
//	EntityManager entityManager = entityManagerFactory.createEntityManager();
//	Query query;
//	int accNumber;
//	LocalDate fromDate;
//	LocalDate toDate;
//	String stmtForDebit="SELECT t.transdt, t.dracno, t.cracno,t.transdesc,t.transamt,t.dracbal FROM Transaction t "
//			+ "where t.transdt between "+fromDate+" and"+toDate+" and t.dracno="+accNumber;
//	String stmtForCredit="SELECT t.transdt, t.dracno, t.cracno,t.transdesc,t.transamt,t.cracbal FROM Transaction t "
//			+ "where t.transdt between "+fromDate+" and"+toDate+" and t.cracno="+accNumber;

	@Override
	public void createTransaction(Transaction applicant) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void modifyTransaction(Transaction applicant) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void removeTransaction(int applicantId) {
		// TODO Auto-generated method stub
		
	}



	@Override
	public List<Transaction> findAllTransaction() {
		
		return super.findAll("Transaction", Transaction.class);
	}

	@Override
	public List<Transaction> findTransaction(int accNumber, LocalDate fromDate,LocalDate toDate) {
		
		List<Transaction> txnList = super.findAll("Transaction", Transaction.class);
//		this.fromDate=fromDate;
//		this.toDate=toDate;
//		this.accNumber=accNumber;
//		
//		for (Transaction transaction : txnList) {
//			if(transaction.getDrAcNumber()==accNumber) {
//				query=entityManager.createQuery(stmtForDebit);
//			}
//			else if(transaction.getCrAcNumber()==accNumber) {
//				query=entityManager.createQuery(stmtForCredit);
//			}
//			else
//				System.out.println("No transactions to display");
//		}
		return txnList;

	}


}
