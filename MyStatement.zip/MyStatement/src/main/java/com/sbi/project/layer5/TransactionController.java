package com.sbi.project.layer5;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.sbi.project.layer2.Transaction;
import com.sbi.project.layer4.TransactionService;
import com.sbi.project.layer4.TransactionServiceImpl;

@CrossOrigin @RestController @RequestMapping("/transactions")
public class TransactionController {
	
	@Autowired
	TransactionService txnService=new TransactionServiceImpl();

	@RequestMapping("/findAllTransaction")
	public List<Transaction> findAllTransaction() {
		return txnService.findAllTransaction();
		
	}
}
