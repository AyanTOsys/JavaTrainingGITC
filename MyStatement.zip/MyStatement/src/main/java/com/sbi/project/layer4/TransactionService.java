package com.sbi.project.layer4;

import java.util.List;

import org.springframework.stereotype.Service;

import com.sbi.project.layer2.Transaction;

@Service
public interface TransactionService {

	List<Transaction> findAllTransaction();
}
