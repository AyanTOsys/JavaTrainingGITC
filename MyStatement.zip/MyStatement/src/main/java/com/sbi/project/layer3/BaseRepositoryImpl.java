package com.sbi.project.layer3;

import java.io.Serializable;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public class BaseRepositoryImpl implements BaseRepository{
	
	@PersistenceContext
	EntityManager em;
	
	public BaseRepositoryImpl(){

	}
	
	@Transactional
	public void persist(Object obj) {
	
		em.persist(obj);
	}
	
	@Transactional
	public void merge(Object obj) {
		em.merge(obj);
	}
	
	@Transactional
	public void remove(Object obj) {
		em.remove(obj);
	}
	
	
//	public <AnyType>AnyType find(Class<AnyType> className, Serializable primaryKey) {
//
//		AnyType anyType=em.find(className, primaryKey);
//		return anyType;
//	}
	

	@Override
	public <AnyType> List<AnyType> findAll(String entityName, Class<AnyType> className) {
		TypedQuery<AnyType> typedQuery=em.createQuery("from "+entityName, className);
		return typedQuery.getResultList();
	}

	@Override
	public <AnyType> List<AnyType> findforSingle(Class<AnyType> className, Serializable primaryKey) {
		
		List<AnyType> anyObj=(List<AnyType>) em.find(className, primaryKey);
		return anyObj;
	}

	
}
