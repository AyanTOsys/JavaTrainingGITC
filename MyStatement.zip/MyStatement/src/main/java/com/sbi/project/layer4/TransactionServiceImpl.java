package com.sbi.project.layer4;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sbi.project.layer2.Transaction;
import com.sbi.project.layer3.TransactionRepository;

@Service
public class TransactionServiceImpl implements TransactionService {
	@Autowired
	TransactionRepository txnRepo;

	@Override
	public List<Transaction> findAllTransaction() {
		
		return txnRepo.findAllTransaction();
	}

}
