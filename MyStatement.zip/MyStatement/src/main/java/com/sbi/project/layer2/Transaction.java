package com.sbi.project.layer2;
import java.time.LocalDate;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import org.springframework.stereotype.Component;

@Component @Entity @Table(name="PROJ_TRANSACTION1")
public class Transaction {
	
	@Id @GeneratedValue @Column(name="transid")
	private int transId;
	
	@Column(name="transdt")
	private LocalDate transDate;
	
	@Column(name="dracno")
	private int drAcNumber;
	
	@Column(name="cracno")
	private int crAcNumber;
	
	@Column(name="transdesc")
	private String transDescription;
	
	@Column(name="transamt")
	private float transAmount;
	
	@Column(name="dracbal")
	private float drAcBalance;
	
	@Column(name="cracbal")
	private float crAcBalance;

	public int getTransId() {
		return transId;
	}

	public void setTransId(int transId) {
		this.transId = transId;
	}

	public LocalDate getTransDate() {
		return transDate;
	}

	public void setTransDate(LocalDate transDate) {
		this.transDate = transDate;
	}

	public int getDrAcNumber() {
		return drAcNumber;
	}

	public void setDrAcNumber(int drAcNumber) {
		this.drAcNumber = drAcNumber;
	}

	public int getCrAcNumber() {
		return crAcNumber;
	}

	public void setCrAcNumber(int crAcNumber) {
		this.crAcNumber = crAcNumber;
	}

	public String getTransDescription() {
		return transDescription;
	}

	public void setTransDescription(String transDescription) {
		this.transDescription = transDescription;
	}

	public float getTransAmount() {
		return transAmount;
	}

	public void setTransAmount(float transAmount) {
		this.transAmount = transAmount;
	}

	public float getDrAcBalance() {
		return drAcBalance;
	}

	public void setDrAcBalance(float drAcBalance) {
		this.drAcBalance = drAcBalance;
	}

	public float getCrAcBalance() {
		return crAcBalance;
	}

	public void setCrAcBalance(float crAcBalance) {
		this.crAcBalance = crAcBalance;
	}	

}
