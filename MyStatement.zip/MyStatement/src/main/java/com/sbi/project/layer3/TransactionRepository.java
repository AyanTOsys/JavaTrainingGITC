package com.sbi.project.layer3;

import java.time.LocalDate;
import java.util.List;
import org.springframework.stereotype.Repository;

import com.sbi.project.layer2.Transaction;


@Repository
public interface TransactionRepository {
	void createTransaction(Transaction applicant);
	void modifyTransaction(Transaction applicant);
	void removeTransaction(int applicantId);
	List<Transaction> findTransaction(int accNumber,LocalDate fromDate, LocalDate toDate);
	List<Transaction> findAllTransaction();
}
