package com.sbi.project;

import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.sbi.project.layer2.Transaction;
import com.sbi.project.layer4.TransactionService;

@SpringBootTest
class MyStatementServiceTests {
	
	@Autowired
	TransactionService txnService;

	@Test
	void findAllTransactionServiceTest() {
		List<Transaction> txnList=txnService.findAllTransaction();
		Assertions.assertTrue(txnList!=null);
		
		for (Transaction transaction : txnList) {
			System.out.println("Transaction Date:"+transaction.getTransDate());
			System.out.println("Transaction Debit Ac:"+transaction.getDrAcNumber());
			System.out.println("Transaction Credit Ac:"+transaction.getCrAcNumber());
			System.out.println("Transaction description:"+transaction.getTransDescription());
			System.out.println("Transaction amount:"+transaction.getTransAmount());
			System.out.println("Transaction Debit Ac Balance:"+transaction.getDrAcBalance());
			System.out.println("Transaction Credit Ac Balance:"+transaction.getCrAcBalance());
			System.out.println("======================================");
		}
		
	}

}
