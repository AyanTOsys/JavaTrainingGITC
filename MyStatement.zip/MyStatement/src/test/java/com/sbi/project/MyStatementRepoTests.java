package com.sbi.project;

import java.time.LocalDate;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.sbi.project.layer2.Transaction;
import com.sbi.project.layer3.TransactionRepository;

@SpringBootTest
class MyStatementRepoTests {
	
	@Autowired
	TransactionRepository txnRepo;

	@Test
	void findAllTransactionRepoTest() {
		List<Transaction> txnList=txnRepo.findAllTransaction();
		Assertions.assertTrue(txnList!=null);
		
		for (Transaction transaction : txnList) {
			System.out.println("Transaction Date:"+transaction.getTransDate());
			System.out.println("Transaction Debit Ac:"+transaction.getDrAcNumber());
			System.out.println("Transaction Credit Ac:"+transaction.getCrAcNumber());
			System.out.println("Transaction description:"+transaction.getTransDescription());
			System.out.println("Transaction amount:"+transaction.getTransAmount());
			System.out.println("Transaction Debit Ac Balance:"+transaction.getDrAcBalance());
			System.out.println("Transaction Credit Ac Balance:"+transaction.getCrAcBalance());
			System.out.println("======================================");
		}
		
	}
	
	@Test
	void findTransactionRepoTest() {
		List<Transaction> txnList=txnRepo.findTransaction(1, LocalDate.of(2022, 4, 1), LocalDate.of(2022, 4, 5));
		Assertions.assertTrue(txnList!=null);
		
		for (Transaction transaction : txnList) {
			System.out.println("Transaction Date:"+transaction.getTransDate());
			System.out.println("Transaction Debit Ac:"+transaction.getDrAcNumber());
			System.out.println("Transaction Credit Ac:"+transaction.getCrAcNumber());
			System.out.println("Transaction description:"+transaction.getTransDescription());
			System.out.println("Transaction amount:"+transaction.getTransAmount());
			System.out.println("Transaction Debit Ac Balance:"+transaction.getDrAcBalance());
			System.out.println("Transaction Credit Ac Balance:"+transaction.getCrAcBalance());
			System.out.println("======================================");
		}
		
	}

}
