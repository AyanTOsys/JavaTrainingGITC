import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CurrencyConverterService {

  constructor() { }

  convertUsdToInrService(amount: number):number{
    console.log('convertUsdToInrService()...');
    return amount*76.37; 
  }
}
