import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Transaction } from './project-statement/Transaction';

@Injectable({
  providedIn: 'root'
})
export class ProjectStatementService {

  baseURL:string="http://localhost:8080/statement";
  constructor(private myHttp:HttpClient) { }

  findTransactionByDateService(): Observable<Transaction[]>{
    return this.myHttp.get<Transaction[]>(this.baseURL+'/getStatement/{acno}/{fromdate}/{todate}');
  }

  findTransactionByAccountService(): Observable<Transaction[]>{
    return this.myHttp.get<Transaction[]>(this.baseURL+'/getStatement/{acno}');
  }
}
