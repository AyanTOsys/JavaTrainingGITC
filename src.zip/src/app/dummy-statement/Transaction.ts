export class Transaction{
    transId:number=0;
    transDate:Date=new Date();
    drAcNumber:number=0;
    crAcNumber:number=0;
    transDescription:string="";
    transAmount:number=0;
    drAcBalance:number=0;
    crAcBalance:number=0;
}