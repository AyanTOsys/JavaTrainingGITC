import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/internal/Observable';
import { Applicant } from './applicant/Applicant';

@Injectable({
  providedIn: 'root'
})
export class ApplicantService {
 
  baseURL:string="http://localhost:8080/applicants";
  constructor(private myhttp:HttpClient) { }

  showAllApplicantsService(): Observable<Applicant[]>{
    return this.myhttp.get<Applicant[]>(this.baseURL+'/getAllApplicants');
  }
}
