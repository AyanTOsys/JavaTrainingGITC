import { DatePipe } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Account } from './statement/Account';
import { Statement } from './statement/Statement';

@Injectable({
  providedIn: 'root'
})
export class StatementService {

  baseURL:string="http://localhost:8080";
  constructor(private myHttp: HttpClient,private datePipe: DatePipe) { }

  getStatementServ(accountnumber:Account,fromDate:Date,toDate:Date): Observable<Statement[]>
  {
    console.log("Date "+ fromDate+"   "+this.datePipe.transform(fromDate, 'yyyyMMdd'));
    // console.log("in getstatentserv");
    // console.log("Year "+fromDate.getFullYear());
    // console.log("month "+fromDate.getUTCMonth());
    // console.log("date "+fromDate.getUTCDate());
    // console.log(this.baseURL+"/statement/getStatement/1001/20220101/20220422");

    console.log(this.baseURL+"/statement/getStatement/"+accountnumber+"/"+this.datePipe.transform(fromDate, 'yyyyMMdd')+"/"+this.datePipe.transform(toDate, 'yyyyMMdd'));
    return this.myHttp.get<Statement[]>(this.baseURL+"/statement/getStatement/"+accountnumber+"/"+this.datePipe.transform(fromDate, 'yyyyMMdd')+"/"+this.datePipe.transform(toDate, 'yyyyMMdd'));
  // return this.myHttp.get<Statement[]>(this.baseURL+"/statement/getStatement/1003/20220101/20220422");
  
  }
}
