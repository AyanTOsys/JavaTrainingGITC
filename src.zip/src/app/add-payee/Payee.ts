export class Payee{
    payeeAcnumber: number=0;
    payeeName: string="";
    payeeIFSC: string="";
    payeeNickname: string="";
    payeeMaxamount: number=0;
}