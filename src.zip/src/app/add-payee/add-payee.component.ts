import { Component, OnInit } from '@angular/core';
import { Payee } from './Payee';

@Component({
  selector: 'app-add-payee',
  templateUrl: './add-payee.component.html',
  styleUrls: ['./add-payee.component.css']
})
export class AddPayeeComponent implements OnInit {

  payeeObj: Payee=new Payee();

  tempAcnumber: number=0;
  errMsg: string="";
  
  payeeArray: Payee[] = [
    {
      payeeAcnumber:123123123123,payeeName:"Jack Stallman",payeeIFSC:"SBI00000062",payeeNickname:"Jacky",payeeMaxamount:1000000
    },
    {
      payeeAcnumber:456456456456,payeeName:"Janet Gates",payeeIFSC:"SBI00000020",payeeNickname:"Jannie",payeeMaxamount:1000000
    },
    {
      payeeAcnumber:783978397839,payeeName:"Julie Barboz",payeeIFSC:"SBI00000019",payeeNickname:"Jul",payeeMaxamount:1000000
    },
    {
      payeeAcnumber:456456123123,payeeName:"Jane Bonanza",payeeIFSC:"SBI00000015",payeeNickname:"Jaan",payeeMaxamount:1000000
    },
    {
      payeeAcnumber:999909999099,payeeName:"Smith Desouza",payeeIFSC:"SBI00000013",payeeNickname:"Smith",payeeMaxamount:1000000
    }
  ];
  constructor() { }
  ngOnInit(): void {
  }

  verifyAcnumber(){
    if(this.payeeObj.payeeAcnumber!=this.tempAcnumber){
      this.errMsg="Both account numbers must match";
    }
    else{
      this.errMsg="";
    }
  }

  addPayee(){
    this.payeeArray.push(this.payeeObj);
  }

  deletePayee(payeeTobedeleted:Payee){
    this.payeeArray=this.payeeArray.filter(item=>item!==payeeTobedeleted);
  }

  tempPayeeArray: Payee[]=this.payeeArray;
  tempPayeeArray2: Payee[]=this.payeeArray;
  reloadPayees(payeeFound: Payee){
    this.tempPayeeArray=this.tempPayeeArray2;
    this.tempPayeeArray=this.tempPayeeArray.filter(item=>item.payeeName.match(payeeFound.payeeName));
    this.payeeArray=this.tempPayeeArray;
  }
}
