import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-simple-interest',
  templateUrl: './simple-interest.component.html',
  styleUrls: ['./simple-interest.component.css']
})
export class SimpleInterestComponent implements OnInit {

  principal: number=10000;
  numberOfYears: number=10;
  rate: number=6.5;
  si: number=0;

  constructor() { }

  ngOnInit(): void {
  }

  calculateSimpleInterest(){
    this.si=(this.principal*this.numberOfYears*this.rate)/100;
  }

}
