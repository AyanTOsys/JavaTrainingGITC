import { Component, OnInit } from '@angular/core';
import { CurrencyConverterService } from '../currency-converter.service';

@Component({
  selector: 'app-currency',
  templateUrl: './currency.component.html',
  styleUrls: ['./currency.component.css']
})
export class CurrencyComponent implements OnInit {

  usdAmt:number=0;
  inrAmt:number=0;

  constructor(private currency:CurrencyConverterService) { 
    console.log('ctor calling service...');
  }

  convertUsdToInr(){
    console.log('convertUsdToInr()...');
    this.inrAmt=this.currency.convertUsdToInrService(this.usdAmt);
  }
  ngOnInit(): void {
  }

}
