import { Component, OnInit } from '@angular/core';
import { Applicant } from './Applicant';

@Component({
  selector: 'app-application-manager',
  templateUrl: './application-manager.component.html',
  styleUrls: ['./application-manager.component.css']
})
export class ApplicationManagerComponent implements OnInit {

  applicant: Applicant = new Applicant();

  errMsg: string="";
  
  applicantArray: Applicant[] = [
    {applicantid:1,acType:"Savings",name:"Sachin",dateofBirth:"2000-12-1",adhaarNumber:131467978913,panNumber:"DAWFE1234M",fatherName:"Ramesh",occupation:"cricket",
      annualIncome:5000000,mobileNumber:7994624556,maritalStatus:"married",photo:"sachin.jpg",applicationStatus:"IN-PROGRESS"},

    {applicantid:2,acType:"Current",name:"Sehwag",dateofBirth:"2001-12-1",adhaarNumber:131467668913,panNumber:"DAWFE4567M",fatherName:"Ramesh",occupation:"cricket",
      annualIncome:4000000,mobileNumber:7994724556,maritalStatus:"married",photo:"sehwag.jpg",applicationStatus:"IN-PROGRESS"}, 
      
    {applicantid:2,acType:"Savings",name:"Sourav",dateofBirth:"1999-12-1",adhaarNumber:131467678963,panNumber:"DAWDW4567M",fatherName:"Chandi",occupation:"cricket",
    annualIncome:8000000,mobileNumber:7764646469,maritalStatus:"married",photo:"sourav.jpg",applicationStatus:"IN-PROGRESS"},  
  ];
  constructor() { }

  ngOnInit(): void {
  }

  approveApplicant(){
    this.applicantArray.push(this.applicant);
  }

  rejectApplicant(applicantTobedeleted:Applicant){
    this.applicantArray=this.applicantArray.filter(item=>item!==applicantTobedeleted);
  }
}

