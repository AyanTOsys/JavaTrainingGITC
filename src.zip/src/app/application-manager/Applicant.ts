import { DatePipe } from '@angular/common'

export class Applicant{
    applicantid: number=0;
    acType: string="";
    name: string="";
    dateofBirth: string="";
    adhaarNumber: number=0;
    panNumber: string="";
    fatherName: string="";
    occupation: string="";
    annualIncome: number=0;
    mobileNumber: number=0;
    maritalStatus: string="";
    photo: string="";
    applicationStatus: string=""; 
}