import { Timestamp } from "rxjs";
import {Account} from './Account';
export class Statement
{
   // a: Account= new Account();

    transactionId: number=0;
    debitAccountNumber: Account= new Account;
    creditAccountNumber: number=0;
    trnType: string="";
    trnAmount: number=0;
    trnDescription: string="";
    trnDateTime: Date = new Date();
    dbAccCurrentBalance: number=0;
    crAccCurrbalance: number=0;
    
}