import { TestBed } from '@angular/core/testing';

import { DummyTransactionService } from './dummy-transaction.service';

describe('DummyTransactionService', () => {
  let service: DummyTransactionService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(DummyTransactionService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
