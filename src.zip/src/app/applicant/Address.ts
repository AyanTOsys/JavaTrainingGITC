export class Address{
    addressid:number=0;
	area:string="";
	street:string="";
	state:string="";
	city:string="";
	country:string="";
	pin:number=0;
	addresstype:string="";
}