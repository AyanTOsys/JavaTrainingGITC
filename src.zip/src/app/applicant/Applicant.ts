import { Address } from "./Address";

export class Applicant{
    applicantId:number=0;
	accountType:string="";
	applicantName:string="";
	dateofBirth:Date=new Date();
	applicantFatherName:string="";
	mobileNumber:number=0;
	adhaarNumber:number=0;
	panNumber:string="";
	married:string="";
	photo:string="";
	occupation:string="";
	annualIncome:number=0;	
	addressList:Address[]=[];
	applicationStatus:string="";
}