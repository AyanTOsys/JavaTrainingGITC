import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CalculatorService {

  constructor() { }

  addTwoNumbersService(x:number, y:number):number{
    console.log('CalculatorService:addTwoNumbersService() invoked...');
    return x+y;
  }

  subtractTwoNumbersService(x:number, y:number):number{
    console.log('CalculatorService:subtractTwoNumbersService() invoked...');
    return x-y;
  }
  multiplyTwoNumbersService(x:number, y:number):number{
    console.log('CalculatorService:multiplyTwoNumbersService() invoked...');
    return x*y;
  }
  divideTwoNumbersService(x:number, y:number):number{
    console.log('CalculatorService:divideTwoNumbersService() invoked...');
    return x/y;
  }
}
