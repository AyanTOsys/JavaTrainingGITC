import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-about-employee',
  templateUrl: './about-employee.component.html',
  styleUrls: ['./about-employee.component.css']
})
export class AboutEmployeeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
