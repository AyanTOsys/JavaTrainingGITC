import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-emi-calculator',
  templateUrl: './emi-calculator.component.html',
  styleUrls: ['./emi-calculator.component.css']
})
export class EmiCalculatorComponent implements OnInit {

  loanAmount: number=100000;
  rate: number=6;
  numberOfYears: number=20;
  emi: number=0;

  constructor() { }

  ngOnInit(): void {
  }

  calculateEmi(){
    this.emi=(this.loanAmount*this.rate*(Math.pow(1+this.rate,this.numberOfYears)))/(Math.pow(1+this.rate,this.numberOfYears)-1);
  }

}
