import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-payee-detail',
  templateUrl: './add-payee-detail.component.html',
  styleUrls: ['./add-payee-detail.component.css']
})
export class AddPayeeDetailComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
