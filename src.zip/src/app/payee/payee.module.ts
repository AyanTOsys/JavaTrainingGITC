import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AddPayeeDetailComponent } from './add-payee-detail/add-payee-detail.component';



@NgModule({
  declarations: [
    AddPayeeDetailComponent
  ],
  imports: [
    CommonModule
  ],
  exports: [
    AddPayeeDetailComponent
  ]
})
export class PayeeModule { }
