import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ProjectStatementComponent } from './project-statement.component';

describe('ProjectStatementComponent', () => {
  let component: ProjectStatementComponent;
  let fixture: ComponentFixture<ProjectStatementComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ProjectStatementComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ProjectStatementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
