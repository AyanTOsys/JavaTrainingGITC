import { Component, OnInit } from '@angular/core';
import { ProjectStatementService } from '../project-statement.service';
import { Transaction } from './Transaction';

@Component({
  selector: 'app-project-statement',
  templateUrl: './project-statement.component.html',
  styleUrls: ['./project-statement.component.css']
})
export class ProjectStatementComponent implements OnInit {

  txnArray:Transaction[]=[];
  constructor(private stmtService:ProjectStatementService) { }

  ngOnInit(): void {
  }

  // findAllTransaction(){
  //   this.stmtService.findAllTransactionService().subscribe(
  //     (data:Transaction[])=>{
  //       this.txnArray=data;
  //     },
  //     (err)=>{
  //       console.log(err);
  //     }
  //   )
  // }
}
