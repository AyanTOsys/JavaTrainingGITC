export class Transaction{
    transactionId:number=0;
    debitAccountNumber:number=0;
    creditAccountNumber:number=0;
    trnType:string="";
    trnAmount:number=0;
    trnDescription:string="";
    trnDateTime:Date=new Date();
    DbAccCurrentBalance:number=0;
    CrAccCurrbalance:number=0;
}