import { TestBed } from '@angular/core/testing';

import { ProjectStatementService } from './project-statement.service';

describe('ProjectStatementService', () => {
  let service: ProjectStatementService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ProjectStatementService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
