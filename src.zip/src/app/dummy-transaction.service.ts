import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Transaction } from './dummy-statement/Transaction';

@Injectable({
  providedIn: 'root'
})
export class DummyTransactionService {

  baseURL:string="http://localhost:8080/transactions";
  constructor(private myHttp:HttpClient) { }

  findAllTransactionService(): Observable<Transaction[]>{
    return this.myHttp.get<Transaction[]>(this.baseURL+'/findAllTransaction');
  }

}
