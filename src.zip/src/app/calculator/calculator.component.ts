import { Component, OnInit } from '@angular/core';
import { CalculatorService } from '../calculator.service';

@Component({
  selector: 'app-calculator',
  templateUrl: './calculator.component.html',
  styleUrls: ['./calculator.component.css']
})
export class CalculatorComponent implements OnInit {

  a:number=0;
  b:number=0;
  answer:number=0;

  constructor(private calcServ : CalculatorService) {
    console.log('Calculator() is calling service()...');
   }

   addTwoNumbers(){
    console.log('Calculator:addTwoNumbers() invoked...');
    this.answer=this.calcServ.addTwoNumbersService(this.a,this.b);
  }

  subtractTwoNumbers(){
    console.log('Calculator:subtractTwoNumbers() invoked...');
    this.answer=this.calcServ.subtractTwoNumbersService(this.a,this.b);
  }
  multiplyTwoNumbers(){
    console.log('Calculator:multiplyTwoNumbers() invoked...');
    this.answer=this.calcServ.multiplyTwoNumbersService(this.a,this.b);
  }
  divideTwoNumbers(){
    console.log('Calculator:divideTwoNumbers() invoked...');
    this.answer=this.calcServ.divideTwoNumbersService(this.a,this.b);
  }

  ngOnInit(): void {
  }

}
